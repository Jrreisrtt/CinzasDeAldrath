# Cinzas de Aldrath (nome provisório)

Protótipo de ação RPG 2D lateral para Android, em Unity (C#). Jogo original: nenhum código, sprite, som
ou nome de Darkrise ou Stickman Legends foi copiado. Os dois jogos serviram só como referência de gênero
(combate em tempo real, habilidades com recarga, progressão por XP).

## Estado atual (leia primeiro)

| Item | Situação |
|---|---|
| Código C# (34 arquivos) | Escrito. **Não foi compilado nem executado** (não havia Unity no ambiente de criação). |
| Verificação feita | Estática: chaves/parênteses balanceados e `using` de todos os tipos do projeto. |
| Verificação pendente | Compilar no Unity, testar na arena, gerar APK, testar em celular. |
| Etapas do roteiro | 1 (movimento e controles), 2 (combate e inimigo), 3 (bola de fogo) e partes da 4 (XP, nível, HUD). |

Se o Unity mostrar erros de compilação, copie as mensagens e envie: é a forma mais rápida de corrigir.

## Como abrir

1. Instale o **Unity Hub** e o **Unity 2022.3 LTS** (o projeto pede 2022.3.62f3; qualquer 2022.3.x costuma abrir)
   com o módulo **Android Build Support** (inclui OpenJDK e Android SDK/NDK).
2. No Hub: **Add > Add project from disk** e escolha esta pasta. Aguarde a importação.
3. Menu **Cinzas de Aldrath > 1. Configurar projeto e criar arena de teste**.
   Isso gera sprites placeholder, assets de dados, prefabs, a cena `Assets/Scenes/TestArena` e as
   configurações de Android (horizontal, IL2CPP, ARMv7 + ARM64, API mínima 24).
4. Abra `TestArena` e aperte **Play**.
5. Antes de publicar, troque `companyName` e o identificador do pacote (`com.seuestudio.cinzasdealdrath`)
   em *Project Settings > Player*.

## Controles

| Ação | Teclado (Editor) | Toque |
|---|---|---|
| Mover | A / D ou setas | Direcional à esquerda (deslize de um lado ao outro) |
| Saltar | Espaço, W ou seta para cima | Botão Pular (segurar = salto mais alto) |
| Ataque básico | J (segurar repete) | Botão Atacar |
| Bola de fogo | K ou 1 | Botão Fogo (mostra recarga) |

Requer *Active Input Handling = Input Manager (Old)*, que é o padrão deste projeto.

## Gerar o APK de teste

Menu **Cinzas de Aldrath > 2. Gerar APK de teste (Android)** gera `Builds/CinzasDeAldrath-teste.apk`
(build de desenvolvimento). Ative a depuração USB no celular e instale com `adb install`.

## Arquitetura

```
Assets/
  Scripts/
    Core/         enums, dano, eventos globais, pool de objetos, entrada (GameInput)
    Combat/       Health, MeleeAttack, KnockbackReceiver, DamagePopup, CombatFeedback, TargetFinder
    Skills/       SkillDefinition (base), ProjectileSkillDefinition, Projectile, SkillCaster, Mana
    Enemies/      EnemyDefinition (dados), EnemyController (IA)
    Progression/  PlayerProgress (XP, nível, ouro)
    Player/       PlayerController
    UI/           HudController, TouchButton, VirtualDPad, SafeAreaFitter, WorldHealthBar
    Visual/       ActorVisual (animação procedural), ImpactFlash
    World/        CameraFollow, GameManager, EnemySpawnPoint
    Audio/        efeitos sonoros sintetizados em código (placeholder)
    SaveSystem/   vazio (etapa 4)
    Inventory/    vazio (etapa 6)
  Editor/         ProjectBootstrapper (monta cena, prefabs e configurações)
```

Decisões principais:

- **Dados fora do código.** Habilidades são `ScriptableObject` (`SkillDefinition`) e inimigos também (`EnemyDefinition`).
- **Nova habilidade = nova subclasse ou novo asset.** Para outro projétil (lanças de gelo), crie um asset em
  *Create > Cinzas > Skills > Projectile Skill*, escolha prefab, dano, recarga, mana, alcance e níveis, e coloque em um
  slot do `SkillCaster` no prefab do jogador. Habilidades de outro tipo (meteoro em área, raio em cadeia) herdam de
  `SkillDefinition` e implementam `Cast`.
- **Um único dano por golpe.** `MeleeAttack` checa a caixa de acerto uma vez por golpe e guarda os alvos já atingidos;
  o projétil explode uma vez. Ficar encostado não repete o dano.
- **Fórmula de dano:** `bruto * 100 / (100 + defesa) * (1 - resistência)`, arredondado, mínimo 1.
- **Sem camadas obrigatórias.** O time (`Team`) decide quem pode ferir quem; `ActorCollisionFilter` evita que
  jogador e inimigos se empurrem.
- **Desempenho.** Projéteis, explosões e números de dano usam `PoolManager`; o projétil faz um `CircleCast` por quadro;
  buffers estáticos evitam alocação nas consultas de física; 60 FPS fixos; sem partículas.
- **Interface.** Canvas 1920x1080 com escala por largura/altura, área segura para notch e multitoque.

## Premissas adotadas

- Orientação horizontal (paisagem), alvo de 60 FPS, Android API 24+.
- Sem anúncios, compras, login ou online nesta versão.
- Arte e sons são placeholders (quadrados, círculos e tons sintetizados). Troque por recursos originais ou licenciados
  em `Assets/Art` e `Assets/Audio`; os componentes não dependem deles.
- Plataformas da arena são de "passar por baixo" (`PlatformEffector2D`).

## Roteiro de testes manual (etapas 1 a 3)

1. Personagem fica no chão, move para os dois lados e não atravessa paredes.
2. Salto curto (toque rápido) e longo (segurando); salto logo depois de sair de uma borda funciona.
3. Ataque básico causa dano, mostra número, e o inimigo recua. Segurar o botão não causa dano duplo no mesmo golpe.
4. Inimigo detecta, persegue, avisa o golpe (pisca amarelo), ataca e causa dano ao jogador com invulnerabilidade de 0,6 s.
5. Bola de fogo: mira no inimigo mais próximo à frente, explode, causa dano em área, gasta 15 de mana, recarrega em 2,5 s.
6. Morte do inimigo concede XP e ouro; ao subir de nível, vida, mana e dano aumentam.
7. Morte do jogador mostra "Derrotado" e reinicia a cena; cair no vazio mata.
8. No celular: dois botões ao mesmo tempo (andar + atacar), notch/área segura, sem queda de FPS.

## Limitações conhecidas

- Animações são procedurais (balanço, squash, flash); ainda não usam sprites nem Animator.
- Controles ainda não são configuráveis (tamanho/posição) e não há menu de pausa nem configurações de áudio.
- Salvamento, inventário, equipamentos, outros inimigos/habilidades, fases e chefes ainda não existem.
- Dentro de uma plataforma de passar por baixo, o teste de chão pode permitir um salto extra (ajuste fino pendente).

## Próximos passos (ordem do roteiro)

1. Compilar e corrigir o que aparecer; validar etapas 1 a 3 no Editor e no celular.
2. Etapa 4: tela de atributos e salvamento local (JSON em `Application.persistentDataPath`; não confiável para economia online).
3. Etapa 5: segundo e terceiro inimigos com comportamentos diferentes, raio elétrico, meteoro, lanças de gelo, primeira fase.
4. Etapa 6: inventário e equipamentos com raridade.
