using System;
using UnityEngine;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.Skills;

namespace CinzasDeAldrath.Progression
{
    /// <summary>Experiência, ouro e nível. Ao subir de nível melhora vida, mana, dano e poder das habilidades.</summary>
    public class PlayerProgress : MonoBehaviour
    {
        [SerializeField] int healthPerLevel = 10;
        [SerializeField] float manaPerLevel = 5f;
        [SerializeField] float meleeDamagePerLevel = 2f;
        [SerializeField] float skillPowerPerLevel = 0.1f;

        Health _health;
        Mana _mana;
        MeleeAttack _melee;
        SkillCaster _caster;
        float _baseHealth, _baseMana, _baseMelee;

        public event Action Changed;
        public event Action<int> LeveledUp;

        public int Level { get; private set; } = 1;
        public int Xp { get; private set; }
        public int Gold { get; private set; }
        public int XpToNext => Mathf.RoundToInt(30f * Mathf.Pow(1.35f, Level - 1));

        void Awake()
        {
            _health = GetComponent<Health>();
            _mana = GetComponent<Mana>();
            _melee = GetComponent<MeleeAttack>();
            _caster = GetComponent<SkillCaster>();
        }

        void OnEnable()
        {
            GameEvents.EnemyKilled += OnEnemyKilled;
        }

        void OnDisable()
        {
            GameEvents.EnemyKilled -= OnEnemyKilled;
        }

        void Start()
        {
            _baseHealth = _health.Max;
            _baseMana = _mana != null ? _mana.Max : 0f;
            _baseMelee = _melee != null ? _melee.Damage : 0f;
            Changed?.Invoke();
        }

        void OnEnemyKilled(EnemyKilledInfo info)
        {
            AddRewards(info.xp, info.gold);
        }

        public void AddRewards(int xp, int gold)
        {
            Xp += xp;
            Gold += gold;
            while (Xp >= XpToNext)
            {
                Xp -= XpToNext;
                Level++;
                ApplyLevel();
                LeveledUp?.Invoke(Level);
            }
            Changed?.Invoke();
        }

        void ApplyLevel()
        {
            int steps = Level - 1;
            _health.SetMax(_baseHealth + healthPerLevel * steps, true);
            if (_mana != null) _mana.SetMax(_baseMana + manaPerLevel * steps, true);
            if (_melee != null) _melee.Damage = _baseMelee + meleeDamagePerLevel * steps;
            if (_caster != null) _caster.DamageMultiplier = 1f + skillPowerPerLevel * steps;
        }
    }
}
