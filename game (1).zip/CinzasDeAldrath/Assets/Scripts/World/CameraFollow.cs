using UnityEngine;

namespace CinzasDeAldrath.World
{
    [RequireComponent(typeof(Camera))]
    public class CameraFollow : MonoBehaviour
    {
        public static CameraFollow Instance { get; private set; }

        [SerializeField] Transform target;
        [SerializeField] Vector2 offset = new Vector2(1f, 1.2f);
        [SerializeField] float smoothTime = 0.15f;
        [SerializeField] bool useBounds;
        [SerializeField] Rect bounds = new Rect(-20f, -8f, 60f, 22f);

        Camera _cam;
        Vector3 _basePosition;
        Vector3 _velocity;
        float _shakeTime;
        float _shakeDuration = 0.001f;
        float _shakeMagnitude;

        void Awake()
        {
            Instance = this;
            _cam = GetComponent<Camera>();
            _basePosition = transform.position;
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void Shake(float magnitude, float duration)
        {
            if (magnitude < _shakeMagnitude * Mathf.Clamp01(_shakeTime / _shakeDuration)) return;
            _shakeMagnitude = magnitude;
            _shakeDuration = Mathf.Max(0.001f, duration);
            _shakeTime = duration;
        }

        void LateUpdate()
        {
            if (target != null)
            {
                Vector3 desired = new Vector3(target.position.x + offset.x, target.position.y + offset.y, _basePosition.z);
                if (useBounds) desired = Clamp(desired);
                _basePosition = Vector3.SmoothDamp(_basePosition, desired, ref _velocity, smoothTime);
            }

            Vector3 shake = Vector3.zero;
            if (_shakeTime > 0f)
            {
                _shakeTime -= Time.deltaTime;
                float k = Mathf.Clamp01(_shakeTime / _shakeDuration);
                shake = (Vector3)(Random.insideUnitCircle * _shakeMagnitude * k);
            }
            transform.position = _basePosition + shake;
        }

        Vector3 Clamp(Vector3 p)
        {
            float halfH = _cam.orthographicSize;
            float halfW = halfH * _cam.aspect;
            p.x = ClampAxis(p.x, bounds.xMin + halfW, bounds.xMax - halfW, bounds.center.x);
            p.y = ClampAxis(p.y, bounds.yMin + halfH, bounds.yMax - halfH, bounds.center.y);
            return p;
        }

        static float ClampAxis(float value, float min, float max, float center)
        {
            return min > max ? center : Mathf.Clamp(value, min, max);
        }
    }
}
