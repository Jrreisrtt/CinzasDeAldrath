using UnityEngine;

namespace CinzasDeAldrath.World
{
    /// <summary>Ponto de surgimento: cria um inimigo no início e, opcionalmente, recria depois de um tempo.</summary>
    public class EnemySpawnPoint : MonoBehaviour
    {
        [SerializeField] GameObject prefab;
        [SerializeField] bool respawn = true;
        [SerializeField] float respawnDelay = 8f;

        GameObject _current;
        float _goneSince = -1f;

        void Start()
        {
            Spawn();
        }

        void Update()
        {
            if (!respawn || _current != null) return;
            if (_goneSince < 0f) _goneSince = Time.time;
            if (Time.time - _goneSince >= respawnDelay) Spawn();
        }

        void Spawn()
        {
            if (prefab == null) return;
            _current = Instantiate(prefab, transform.position, Quaternion.identity);
            _goneSince = -1f;
        }

        void OnDrawGizmos()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, 0.4f);
        }
    }
}
