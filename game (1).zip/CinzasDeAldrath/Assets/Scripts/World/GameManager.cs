using UnityEngine;
using UnityEngine.SceneManagement;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.PlayerControl;
using CinzasDeAldrath.UI;

namespace CinzasDeAldrath.World
{
    /// <summary>Configurações globais do protótipo, queda no vazio e reinício ao morrer.</summary>
    public class GameManager : MonoBehaviour
    {
        [SerializeField] PlayerController player;
        [SerializeField] HudController hud;
        [SerializeField] float killY = -15f;
        [SerializeField] float reloadDelay = 3f;

        bool _ending;

        void Awake()
        {
            Application.targetFrameRate = 60;
            QualitySettings.vSyncCount = 0;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }

        void Start()
        {
            if (player != null) player.Health.Died += OnPlayerDied;
        }

        void OnDestroy()
        {
            if (player != null) player.Health.Died -= OnPlayerDied;
        }

        void Update()
        {
            if (!_ending && player != null && player.transform.position.y < killY)
                player.Health.Kill();
        }

        void OnPlayerDied(Health h, DamageInfo info)
        {
            if (_ending) return;
            _ending = true;
            if (hud != null) hud.ShowMessage("Derrotado");
            Invoke(nameof(ReloadScene), reloadDelay);
        }

        void ReloadScene()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }
}
