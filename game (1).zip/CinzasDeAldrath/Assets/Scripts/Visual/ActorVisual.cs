using UnityEngine;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Visual
{
    /// <summary>
    /// Animação procedural para os placeholders: respiração, corrida, salto, impacto e morte.
    /// O "body" é um pivô nos pés. Quando houver sprites/Animator de verdade, este componente
    /// continua útil para flash de dano e squash/stretch.
    /// </summary>
    public class ActorVisual : MonoBehaviour
    {
        [SerializeField] Transform body;
        [SerializeField] SpriteRenderer sprite;
        [SerializeField] Color baseColor = Color.white;
        [SerializeField] float flashDuration = 0.1f;

        Health _health;
        MeleeAttack _melee;
        Vector3 _baseScale = Vector3.one;
        Vector2 _squash = Vector2.one;
        Color _flashColor;
        float _flashUntil;
        float _t;
        float _deathT;
        float _speed01;
        bool _grounded = true;
        bool _dead;

        public int Facing { get; set; } = 1;

        void Awake()
        {
            _health = GetComponent<Health>();
            _melee = GetComponent<MeleeAttack>();
            if (body != null) _baseScale = body.localScale;
            if (sprite != null) sprite.color = baseColor;
        }

        void OnEnable()
        {
            if (_health != null)
            {
                _health.Damaged += OnDamaged;
                _health.Died += OnDied;
            }
            if (_melee != null) _melee.WindupStarted += OnWindup;
        }

        void OnDisable()
        {
            if (_health != null)
            {
                _health.Damaged -= OnDamaged;
                _health.Died -= OnDied;
            }
            if (_melee != null) _melee.WindupStarted -= OnWindup;
        }

        public void SetBaseColor(Color color)
        {
            baseColor = color;
            if (sprite != null) sprite.color = color;
        }

        public void SetMotion(float speed01, bool grounded)
        {
            _speed01 = speed01;
            _grounded = grounded;
        }

        public void Squash(float x, float y)
        {
            _squash = new Vector2(x, y);
        }

        public void Flash(Color color, float duration)
        {
            _flashColor = color;
            _flashUntil = Time.time + duration;
        }

        void OnDamaged(Health h, float amount, DamageInfo info)
        {
            Flash(Color.white, flashDuration);
            Squash(0.8f, 1.2f);
        }

        void OnDied(Health h, DamageInfo info)
        {
            _dead = true;
            _deathT = 0f;
        }

        void OnWindup(float windup)
        {
            // Aviso visual do golpe; para inimigos serve de "telegrafia" para o jogador reagir.
            if (_health != null && _health.Team == Team.Enemy)
                Flash(new Color(1f, 0.9f, 0.3f), Mathf.Max(0.05f, windup));
            else
                Squash(1.15f, 0.9f);
        }

        void LateUpdate()
        {
            if (body == null) return;

            _t += Time.deltaTime;
            _squash = Vector2.Lerp(_squash, Vector2.one, 12f * Time.deltaTime);

            Vector2 s;
            if (!_grounded)
            {
                s = new Vector2(0.92f, 1.1f);
            }
            else if (_speed01 > 0.1f)
            {
                float b = Mathf.Sin(_t * 18f) * 0.06f;
                s = new Vector2(1f - b, 1f + b);
            }
            else
            {
                float b = Mathf.Sin(_t * 3f) * 0.025f;
                s = new Vector2(1f - b, 1f + b);
            }
            s = Vector2.Scale(s, _squash);

            body.localScale = new Vector3(_baseScale.x * s.x * Facing, _baseScale.y * s.y, _baseScale.z);

            if (sprite == null) return;

            if (_dead)
            {
                _deathT += Time.deltaTime;
                float k = Mathf.Clamp01(_deathT / 0.8f);
                var c = baseColor;
                c.a = 1f - k;
                sprite.color = c;
                body.localRotation = Quaternion.Euler(0f, 0f, -80f * Facing * k);
            }
            else
            {
                sprite.color = Time.time < _flashUntil ? _flashColor : baseColor;
            }
        }
    }
}
