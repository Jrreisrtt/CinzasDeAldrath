using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Visual
{
    /// <summary>Clarão circular que cresce e some (explosão simples, sem partículas).</summary>
    [RequireComponent(typeof(SpriteRenderer))]
    public class ImpactFlash : MonoBehaviour
    {
        [SerializeField] float duration = 0.25f;

        SpriteRenderer _sr;
        Color _baseColor;
        float _radius = 0.6f;
        float _t;

        void Awake()
        {
            _sr = GetComponent<SpriteRenderer>();
            _baseColor = _sr.color;
        }

        void OnEnable()
        {
            _t = 0f;
        }

        public void Play(float radius)
        {
            _radius = radius;
            _t = 0f;
            transform.localScale = Vector3.one * radius * 1.2f;
            _sr.color = _baseColor;
        }

        void Update()
        {
            _t += Time.deltaTime;
            float k = _t / duration;
            if (k >= 1f)
            {
                PoolManager.Despawn(gameObject);
                return;
            }
            float ease = 1f - (1f - k) * (1f - k);
            transform.localScale = Vector3.one * Mathf.Lerp(_radius * 1.2f, _radius * 2f, ease);
            var c = _baseColor;
            c.a = _baseColor.a * (1f - k);
            _sr.color = c;
        }
    }
}
