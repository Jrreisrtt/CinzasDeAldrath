using UnityEngine;
using UnityEngine.EventSystems;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.UI
{
    /// <summary>
    /// Direcional esquerda/direita em uma única área: o dedo pode deslizar de um lado ao outro
    /// sem soltar a tela.
    /// </summary>
    [RequireComponent(typeof(RectTransform))]
    public class VirtualDPad : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [SerializeField, Range(0f, 0.5f)] float deadZone = 0.12f;

        RectTransform _rt;

        void Awake()
        {
            _rt = (RectTransform)transform;
        }

        public void OnPointerDown(PointerEventData e) { Apply(e); }
        public void OnDrag(PointerEventData e) { Apply(e); }
        public void OnPointerUp(PointerEventData e) { Release(); }
        void OnDisable() { Release(); }

        void Apply(PointerEventData e)
        {
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(_rt, e.position, e.pressEventCamera, out Vector2 local))
                return;
            float n = (local.x - _rt.rect.center.x) / (_rt.rect.width * 0.5f);
            GameInput.SetHeld(ButtonId.Left, n < -deadZone);
            GameInput.SetHeld(ButtonId.Right, n > deadZone);
        }

        void Release()
        {
            GameInput.SetHeld(ButtonId.Left, false);
            GameInput.SetHeld(ButtonId.Right, false);
        }
    }
}
