using UnityEngine;
using UnityEngine.EventSystems;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.UI
{
    /// <summary>Botão de tela que reporta pressionado/solto para GameInput (suporta multitoque).</summary>
    public class TouchButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler
    {
        public ButtonId id;

        public void OnPointerDown(PointerEventData eventData)
        {
            GameInput.SetHeld(id, true);
        }

        public void OnPointerUp(PointerEventData eventData)
        {
            GameInput.SetHeld(id, false);
        }

        void OnDisable()
        {
            GameInput.SetHeld(id, false);
        }
    }
}
