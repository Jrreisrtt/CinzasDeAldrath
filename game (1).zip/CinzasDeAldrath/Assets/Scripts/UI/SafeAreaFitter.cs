using UnityEngine;

namespace CinzasDeAldrath.UI
{
    /// <summary>Mantém o HUD dentro da área segura (notch, cantos arredondados, barra de gestos).</summary>
    [RequireComponent(typeof(RectTransform))]
    public class SafeAreaFitter : MonoBehaviour
    {
        RectTransform _rt;
        Rect _lastArea;
        Vector2Int _lastResolution;

        void Awake()
        {
            _rt = (RectTransform)transform;
            Apply();
        }

        void Update()
        {
            if (Screen.safeArea != _lastArea || Screen.width != _lastResolution.x || Screen.height != _lastResolution.y)
                Apply();
        }

        void Apply()
        {
            Rect area = Screen.safeArea;
            _lastArea = area;
            _lastResolution = new Vector2Int(Screen.width, Screen.height);
            if (Screen.width <= 0 || Screen.height <= 0) return;

            Vector2 min = area.position;
            Vector2 max = area.position + area.size;
            min.x /= Screen.width; min.y /= Screen.height;
            max.x /= Screen.width; max.y /= Screen.height;

            _rt.anchorMin = min;
            _rt.anchorMax = max;
            _rt.offsetMin = Vector2.zero;
            _rt.offsetMax = Vector2.zero;
        }
    }
}
