using UnityEngine;
using CinzasDeAldrath.Combat;

namespace CinzasDeAldrath.UI
{
    /// <summary>Barra de vida sobre a cabeça de inimigos (feita com sprites, sem Canvas).</summary>
    public class WorldHealthBar : MonoBehaviour
    {
        [SerializeField] Health health;
        [SerializeField] Transform fill;
        [SerializeField] float width = 1f;
        [SerializeField] float height = 0.12f;
        [SerializeField] GameObject visualRoot;

        void OnEnable()
        {
            if (health != null) health.Changed += Refresh;
        }

        void OnDisable()
        {
            if (health != null) health.Changed -= Refresh;
        }

        void Start()
        {
            Refresh(health);
        }

        void Refresh(Health h)
        {
            if (health == null || fill == null) return;
            float ratio = health.Max > 0f ? Mathf.Clamp01(health.Current / health.Max) : 0f;
            fill.localScale = new Vector3(width * ratio, height * 0.8f, 1f);
            fill.localPosition = new Vector3(-width * (1f - ratio) * 0.5f, 0f, 0f);
            if (visualRoot != null) visualRoot.SetActive(ratio < 1f && !health.IsDead);
        }
    }
}
