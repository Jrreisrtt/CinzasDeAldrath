using UnityEngine;
using UnityEngine.UI;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Progression;
using CinzasDeAldrath.Skills;

namespace CinzasDeAldrath.UI
{
    /// <summary>HUD de combate: vida, mana, experiência, nível, ouro e recarga das habilidades.</summary>
    public class HudController : MonoBehaviour
    {
        public Health playerHealth;
        public Mana playerMana;
        public PlayerProgress progress;
        public SkillCaster caster;

        public Image healthFill;
        public Image manaFill;
        public Image xpFill;
        public Text healthText;
        public Text levelText;
        public Text goldText;
        public Text messageText;

        public GameObject[] skillButtons;
        public Text[] skillLabels;
        public Image[] skillCooldownOverlays;
        public Text[] skillCooldownTexts;

        void Start()
        {
            if (messageText != null) messageText.text = "";
            if (caster == null || skillButtons == null) return;

            for (int i = 0; i < skillButtons.Length; i++)
            {
                var skill = caster.GetSkill(i);
                skillButtons[i].SetActive(skill != null);
                if (skill != null && skillLabels != null && i < skillLabels.Length)
                    skillLabels[i].text = skill.displayName;
            }
        }

        void Update()
        {
            if (playerHealth != null)
            {
                if (healthFill != null) healthFill.fillAmount = playerHealth.Max > 0f ? playerHealth.Current / playerHealth.Max : 0f;
                if (healthText != null) healthText.text = Mathf.CeilToInt(playerHealth.Current) + " / " + Mathf.CeilToInt(playerHealth.Max);
            }

            if (playerMana != null && manaFill != null)
                manaFill.fillAmount = playerMana.Max > 0f ? playerMana.Current / playerMana.Max : 0f;

            if (progress != null)
            {
                if (xpFill != null) xpFill.fillAmount = progress.XpToNext > 0 ? (float)progress.Xp / progress.XpToNext : 0f;
                if (levelText != null) levelText.text = "Nv " + progress.Level;
                if (goldText != null) goldText.text = "Ouro " + progress.Gold;
            }

            if (caster == null || skillCooldownOverlays == null) return;
            for (int i = 0; i < skillCooldownOverlays.Length; i++)
            {
                if (skillCooldownOverlays[i] == null) continue;
                skillCooldownOverlays[i].fillAmount = caster.CooldownFraction(i);
                if (skillCooldownTexts != null && i < skillCooldownTexts.Length && skillCooldownTexts[i] != null)
                {
                    float remaining = caster.CooldownRemaining(i);
                    skillCooldownTexts[i].text = remaining > 0.05f ? remaining.ToString("0.0") : "";
                }
            }
        }

        public void ShowMessage(string text)
        {
            if (messageText != null) messageText.text = text;
        }
    }
}
