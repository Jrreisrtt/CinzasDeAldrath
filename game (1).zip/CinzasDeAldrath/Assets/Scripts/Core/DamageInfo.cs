using UnityEngine;

namespace CinzasDeAldrath.Core
{
    public struct DamageInfo
    {
        public float amount;
        public DamageType type;
        public Team sourceTeam;
        public Vector2 knockback;
        public GameObject source;
        public bool isCritical;

        public DamageInfo(float amount, DamageType type, Team sourceTeam, Vector2 knockback, GameObject source = null, bool isCritical = false)
        {
            this.amount = amount;
            this.type = type;
            this.sourceTeam = sourceTeam;
            this.knockback = knockback;
            this.source = source;
            this.isCritical = isCritical;
        }
    }
}
