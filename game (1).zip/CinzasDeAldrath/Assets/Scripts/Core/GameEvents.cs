using System;
using UnityEngine;

namespace CinzasDeAldrath.Core
{
    public struct EnemyKilledInfo
    {
        public string enemyId;
        public int xp;
        public int gold;
        public Vector2 position;
    }

    /// <summary>Eventos globais simples. Mantidos poucos de propósito.</summary>
    public static class GameEvents
    {
        public static event Action<EnemyKilledInfo> EnemyKilled;

        public static void RaiseEnemyKilled(EnemyKilledInfo info)
        {
            EnemyKilled?.Invoke(info);
        }

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            EnemyKilled = null;
        }
    }
}
