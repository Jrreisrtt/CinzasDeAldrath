using System;
using UnityEngine;

namespace CinzasDeAldrath.Core
{
    /// <summary>
    /// Ponto único de entrada: botões de toque + teclado (para testar no Editor).
    /// Requer "Active Input Handling = Input Manager (Old)" (padrão do projeto).
    /// </summary>
    public static class GameInput
    {
        const int Count = 8;
        static readonly bool[] Held = new bool[Count];
        static readonly bool[] Pressed = new bool[Count];
        static readonly KeyCode[] SkillKeys = { KeyCode.Alpha1, KeyCode.Alpha2, KeyCode.Alpha3 };
        static readonly KeyCode[] SkillAltKeys = { KeyCode.K, KeyCode.L, KeyCode.Semicolon };

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetState()
        {
            Array.Clear(Held, 0, Count);
            Array.Clear(Pressed, 0, Count);
        }

        public static void SetHeld(ButtonId id, bool value)
        {
            int i = (int)id;
            if (value && !Held[i]) Pressed[i] = true;
            Held[i] = value;
        }

        static bool Consume(ButtonId id)
        {
            int i = (int)id;
            bool p = Pressed[i];
            Pressed[i] = false;
            return p;
        }

        public static float Horizontal
        {
            get
            {
                float x = 0f;
                if (Held[(int)ButtonId.Left]) x -= 1f;
                if (Held[(int)ButtonId.Right]) x += 1f;
                x += Input.GetAxisRaw("Horizontal");
                return Mathf.Clamp(x, -1f, 1f);
            }
        }

        public static bool JumpHeld =>
            Held[(int)ButtonId.Jump] || Input.GetKey(KeyCode.Space) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.UpArrow);

        // Chamar somente em Update (usa GetKeyDown).
        public static bool ConsumeJump()
        {
            bool touch = Consume(ButtonId.Jump);
            bool key = Input.GetKeyDown(KeyCode.Space) || Input.GetKeyDown(KeyCode.W) || Input.GetKeyDown(KeyCode.UpArrow);
            return touch || key;
        }

        public static bool AttackRequested()
        {
            bool pressed = Consume(ButtonId.Attack);
            return pressed || Held[(int)ButtonId.Attack] || Input.GetKey(KeyCode.J);
        }

        public static bool ConsumeSkill(int index)
        {
            var id = (ButtonId)((int)ButtonId.Skill1 + index);
            bool touch = Consume(id);
            bool key = Input.GetKeyDown(SkillKeys[index]) || Input.GetKeyDown(SkillAltKeys[index]);
            return touch || key;
        }

        public static bool ConsumeInteract()
        {
            bool touch = Consume(ButtonId.Interact);
            return touch || Input.GetKeyDown(KeyCode.E);
        }
    }
}
