namespace CinzasDeAldrath.Core
{
    public enum Team { Player = 0, Enemy = 1, Neutral = 2 }

    public enum DamageType { Physical = 0, Fire = 1, Ice = 2, Lightning = 3, Arcane = 4 }

    public enum ButtonId { Left = 0, Right = 1, Jump = 2, Attack = 3, Skill1 = 4, Skill2 = 5, Skill3 = 6, Interact = 7 }
}
