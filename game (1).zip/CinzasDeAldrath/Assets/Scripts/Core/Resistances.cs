using System;
using UnityEngine;

namespace CinzasDeAldrath.Core
{
    /// <summary>Resistência por tipo de dano. 0 = normal, 0.5 = metade do dano, -0.5 = 50% a mais, 1 = imune.</summary>
    [Serializable]
    public class Resistances
    {
        [Range(-1f, 1f)] public float physical;
        [Range(-1f, 1f)] public float fire;
        [Range(-1f, 1f)] public float ice;
        [Range(-1f, 1f)] public float lightning;
        [Range(-1f, 1f)] public float arcane;

        public float Get(DamageType type)
        {
            switch (type)
            {
                case DamageType.Fire: return fire;
                case DamageType.Ice: return ice;
                case DamageType.Lightning: return lightning;
                case DamageType.Arcane: return arcane;
                default: return physical;
            }
        }
    }
}
