using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace CinzasDeAldrath.Core
{
    /// <summary>Marca um objeto como pertencente a um pool.</summary>
    public class PooledObject : MonoBehaviour
    {
        [HideInInspector] public int key;
        [HideInInspector] public bool inPool;
    }

    /// <summary>Pool simples por prefab (projéteis, efeitos, números de dano).</summary>
    public static class PoolManager
    {
        static readonly Dictionary<int, Queue<GameObject>> Pools = new Dictionary<int, Queue<GameObject>>();
        static Transform _root;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            Pools.Clear();
            _root = null;
        }

        static Transform Root
        {
            get
            {
                if (_root == null)
                {
                    var go = new GameObject("[Pool]");
                    Object.DontDestroyOnLoad(go);
                    _root = go.transform;
                }
                return _root;
            }
        }

        public static GameObject Spawn(GameObject prefab, Vector3 position, Quaternion rotation)
        {
            int key = prefab.GetInstanceID();
            GameObject go = null;

            if (Pools.TryGetValue(key, out var queue))
            {
                while (queue.Count > 0 && go == null)
                    go = queue.Dequeue();
            }

            if (go == null)
            {
                go = Object.Instantiate(prefab, position, rotation);
                var pooled = go.GetComponent<PooledObject>();
                if (pooled == null) pooled = go.AddComponent<PooledObject>();
                pooled.key = key;
                pooled.inPool = false;
                return go;
            }

            go.transform.SetParent(null, false);
            SceneManager.MoveGameObjectToScene(go, SceneManager.GetActiveScene());
            go.transform.SetPositionAndRotation(position, rotation);
            go.GetComponent<PooledObject>().inPool = false;
            go.SetActive(true);
            return go;
        }

        public static void Despawn(GameObject go)
        {
            if (go == null) return;
            var pooled = go.GetComponent<PooledObject>();
            if (pooled == null)
            {
                Object.Destroy(go);
                return;
            }
            if (pooled.inPool) return;

            pooled.inPool = true;
            go.SetActive(false);
            go.transform.SetParent(Root, false);

            if (!Pools.TryGetValue(pooled.key, out var queue))
            {
                queue = new Queue<GameObject>();
                Pools[pooled.key] = queue;
            }
            queue.Enqueue(go);
        }
    }
}
