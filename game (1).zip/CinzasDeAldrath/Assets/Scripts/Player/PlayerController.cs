using System;
using UnityEngine;
using CinzasDeAldrath.Audio;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.Skills;
using CinzasDeAldrath.Visual;

namespace CinzasDeAldrath.PlayerControl
{
    /// <summary>
    /// Movimento lateral, salto (com coyote time e buffer), ataque básico e habilidades.
    /// Lê os comandos de GameInput (toque + teclado).
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D), typeof(Collider2D), typeof(Health))]
    public class PlayerController : MonoBehaviour
    {
        [Header("Movimento")]
        [SerializeField] float moveSpeed = 7f;
        [SerializeField] float attackMoveMultiplier = 0.6f;
        [SerializeField] float groundAcceleration = 70f;
        [SerializeField] float airAcceleration = 40f;

        [Header("Salto")]
        [SerializeField] float jumpVelocity = 13f;
        [SerializeField] float coyoteTime = 0.1f;
        [SerializeField] float jumpBufferTime = 0.12f;
        [SerializeField] float gravity = 3f;
        [SerializeField] float fallGravityMultiplier = 1.6f;
        [SerializeField] float jumpCutGravityMultiplier = 2.5f;
        [SerializeField] float groundCheckDistance = 0.1f;

        static readonly RaycastHit2D[] GroundHits = new RaycastHit2D[8];

        Rigidbody2D _rb;
        Collider2D _col;
        Health _health;
        MeleeAttack _melee;
        SkillCaster _caster;
        KnockbackReceiver _knock;
        ActorVisual _visual;
        ContactFilter2D _filter;
        float _coyote;
        float _jumpBuffer;

        public int Facing { get; private set; } = 1;
        public bool IsGrounded { get; private set; }
        public Health Health => _health;

        public event Action Jumped;

        void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();
            _col = GetComponent<Collider2D>();
            _health = GetComponent<Health>();
            _melee = GetComponent<MeleeAttack>();
            _caster = GetComponent<SkillCaster>();
            _knock = GetComponent<KnockbackReceiver>();
            _visual = GetComponent<ActorVisual>();

            _rb.gravityScale = gravity;
            _rb.freezeRotation = true;
            _filter = new ContactFilter2D();
            _filter.useTriggers = false;
        }

        void Update()
        {
            // Sempre consome as entradas para não acumular comandos antigos.
            bool jump = GameInput.ConsumeJump();
            bool attack = GameInput.AttackRequested();
            bool skill0 = GameInput.ConsumeSkill(0);
            bool skill1 = GameInput.ConsumeSkill(1);
            bool skill2 = GameInput.ConsumeSkill(2);
            GameInput.ConsumeInteract();

            if (_health.IsDead) return;

            if (jump) _jumpBuffer = jumpBufferTime;

            if (attack && _melee != null && _melee.TryAttack(Facing))
                SfxPlayer.Play(ProceduralSfx.Swing, 0.6f);

            if (_caster != null)
            {
                if (skill0) _caster.TryCast(0, Facing);
                if (skill1) _caster.TryCast(1, Facing);
                if (skill2) _caster.TryCast(2, Facing);
            }

            if (_visual != null)
            {
                _visual.Facing = Facing;
                _visual.SetMotion(Mathf.Abs(_rb.velocity.x) / moveSpeed, IsGrounded);
            }
        }

        void FixedUpdate()
        {
            float dt = Time.fixedDeltaTime;
            IsGrounded = CheckGrounded();
            _coyote = IsGrounded ? coyoteTime : _coyote - dt;
            _jumpBuffer -= dt;

            Vector2 v = _rb.velocity;

            if (_health.IsDead)
            {
                v.x = Mathf.MoveTowards(v.x, 0f, groundAcceleration * dt);
                _rb.velocity = v;
                return;
            }

            if (_knock == null || !_knock.IsStunned)
            {
                float input = GameInput.Horizontal;
                float speed = moveSpeed * (_melee != null && _melee.IsAttacking ? attackMoveMultiplier : 1f);
                float accel = IsGrounded ? groundAcceleration : airAcceleration;
                v.x = Mathf.MoveTowards(v.x, input * speed, accel * dt);

                if (Mathf.Abs(input) > 0.1f) Facing = input > 0f ? 1 : -1;

                if (_jumpBuffer > 0f && _coyote > 0f)
                {
                    v.y = jumpVelocity;
                    _jumpBuffer = 0f;
                    _coyote = 0f;
                    Jumped?.Invoke();
                    SfxPlayer.Play(ProceduralSfx.Jump, 0.4f);
                    if (_visual != null) _visual.Squash(0.8f, 1.25f);
                }

                _rb.velocity = v;
            }

            // Gravidade variável: cai mais rápido e solta o botão para saltos curtos.
            if (v.y < 0f) _rb.gravityScale = gravity * fallGravityMultiplier;
            else if (v.y > 0f && !GameInput.JumpHeld) _rb.gravityScale = gravity * jumpCutGravityMultiplier;
            else _rb.gravityScale = gravity;
        }

        bool CheckGrounded()
        {
            Bounds b = _col.bounds;
            Vector2 size = new Vector2(b.size.x * 0.9f, b.size.y);
            int n = Physics2D.BoxCast(b.center, size, 0f, Vector2.down, _filter, GroundHits, groundCheckDistance);
            for (int i = 0; i < n; i++)
            {
                var hit = GroundHits[i];
                if (hit.collider == null || hit.collider == _col) continue;
                if (hit.collider.GetComponentInParent<Health>() != null) continue; // não é chão: outro personagem
                if (hit.normal.y > 0.6f) return true;
            }
            return false;
        }
    }
}
