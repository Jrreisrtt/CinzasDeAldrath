using System;
using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Skills
{
    /// <summary>Modificadores por nível de uma habilidade.</summary>
    [Serializable]
    public class SkillLevel
    {
        public float damageMultiplier = 1f;
        public float rangeMultiplier = 1f;
        public float areaRadius = 0f;
        public float cooldownMultiplier = 1f;
        public int upgradeCost = 1;
    }

    public struct SkillCastContext
    {
        public GameObject caster;
        public Team team;
        public Vector2 origin;
        public int facing;
        public int level;
        public float damageMultiplier;
    }

    /// <summary>
    /// Base de todas as habilidades. Para criar um novo tipo: herde desta classe e implemente Cast.
    /// Os números (dano, recarga, alcance...) ficam no asset, não no código.
    /// </summary>
    public abstract class SkillDefinition : ScriptableObject
    {
        public string skillId = "skill";
        public string displayName = "Habilidade";
        [TextArea] public string description;
        public DamageType damageType = DamageType.Physical;
        public float baseDamage = 10f;
        public float range = 8f;
        public float cooldown = 2f;
        public float manaCost = 10f;
        public SkillLevel[] levels = { new SkillLevel() };

        public SkillLevel GetLevel(int level)
        {
            if (levels == null || levels.Length == 0) return new SkillLevel();
            return levels[Mathf.Clamp(level - 1, 0, levels.Length - 1)];
        }

        /// <summary>Executa a habilidade. Retorna false se não foi possível (a recarga e o mana não são gastos).</summary>
        public abstract bool Cast(SkillCastContext context);
    }
}
