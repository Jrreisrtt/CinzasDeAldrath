using UnityEngine;
using CinzasDeAldrath.Audio;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Skills
{
    /// <summary>Habilidade que dispara um projétil (bola de fogo, lanças de gelo, flechas...).</summary>
    [CreateAssetMenu(menuName = "Cinzas/Skills/Projectile Skill", fileName = "NovaHabilidadeProjetil")]
    public class ProjectileSkillDefinition : SkillDefinition
    {
        public Projectile projectilePrefab;
        public GameObject impactPrefab;
        public float projectileSpeed = 12f;
        public float knockback = 4f;
        [Tooltip("Mira automaticamente no inimigo mais próximo à frente, dentro do alcance.")]
        public bool aimAtNearestEnemy = true;

        public override bool Cast(SkillCastContext ctx)
        {
            if (projectilePrefab == null) return false;

            var lvl = GetLevel(ctx.level);
            float finalRange = range * lvl.rangeMultiplier;
            Vector2 dir = new Vector2(ctx.facing, 0f);

            if (aimAtNearestEnemy)
            {
                var target = TargetFinder.FindNearestEnemy(ctx.origin, finalRange, ctx.team, ctx.facing, true);
                if (target != null)
                {
                    Vector2 to = target.CenterPosition - ctx.origin;
                    if (to.sqrMagnitude > 0.01f) dir = to.normalized;
                }
            }

            var go = PoolManager.Spawn(projectilePrefab.gameObject, ctx.origin, Quaternion.identity);
            var projectile = go.GetComponent<Projectile>();
            projectile.Launch(new Projectile.LaunchData
            {
                team = ctx.team,
                damage = baseDamage * lvl.damageMultiplier * ctx.damageMultiplier,
                type = damageType,
                speed = projectileSpeed,
                maxDistance = finalRange,
                areaRadius = lvl.areaRadius,
                direction = dir,
                impactPrefab = impactPrefab,
                knockback = knockback,
                source = ctx.caster
            });

            SfxPlayer.Play(ProceduralSfx.Cast, 0.6f);
            return true;
        }
    }
}
