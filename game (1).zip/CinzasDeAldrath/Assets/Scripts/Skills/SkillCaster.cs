using System;
using UnityEngine;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Skills
{
    /// <summary>Gerencia os slots de habilidade, recarga e custo de mana de um personagem.</summary>
    [RequireComponent(typeof(Health))]
    public class SkillCaster : MonoBehaviour
    {
        [Serializable]
        public class Slot
        {
            public SkillDefinition skill;
            [Min(1)] public int level = 1;
            [NonSerialized] public float readyAt;
        }

        [SerializeField] Slot[] slots = new Slot[3];
        [SerializeField] Vector2 castOffset = new Vector2(0.7f, 0.15f);

        Health _health;
        Mana _mana;

        public event Action<int, SkillDefinition> SkillCast;
        public event Action<int> NotEnoughMana;

        public float DamageMultiplier { get; set; } = 1f;
        public int SlotCount => slots.Length;

        void Awake()
        {
            _health = GetComponent<Health>();
            _mana = GetComponent<Mana>();
        }

        Slot GetSlot(int index)
        {
            if (index < 0 || index >= slots.Length) return null;
            return slots[index];
        }

        public SkillDefinition GetSkill(int index)
        {
            var slot = GetSlot(index);
            return slot != null ? slot.skill : null;
        }

        public float CooldownRemaining(int index)
        {
            var slot = GetSlot(index);
            return slot == null ? 0f : Mathf.Max(0f, slot.readyAt - Time.time);
        }

        public float CooldownFraction(int index)
        {
            var slot = GetSlot(index);
            if (slot == null || slot.skill == null) return 0f;
            float total = slot.skill.cooldown * slot.skill.GetLevel(slot.level).cooldownMultiplier;
            return total <= 0f ? 0f : Mathf.Clamp01(CooldownRemaining(index) / total);
        }

        public bool TryCast(int index, int facing)
        {
            var slot = GetSlot(index);
            if (slot == null || slot.skill == null || _health.IsDead) return false;
            if (Time.time < slot.readyAt) return false;

            var skill = slot.skill;
            if (_mana != null && !_mana.CanSpend(skill.manaCost))
            {
                NotEnoughMana?.Invoke(index);
                return false;
            }

            int dir = facing >= 0 ? 1 : -1;
            var ctx = new SkillCastContext
            {
                caster = gameObject,
                team = _health.Team,
                origin = (Vector2)transform.position + new Vector2(castOffset.x * dir, castOffset.y),
                facing = dir,
                level = slot.level,
                damageMultiplier = DamageMultiplier
            };

            if (!skill.Cast(ctx)) return false;

            if (_mana != null) _mana.Spend(skill.manaCost);
            slot.readyAt = Time.time + skill.cooldown * skill.GetLevel(slot.level).cooldownMultiplier;
            SkillCast?.Invoke(index, skill);
            return true;
        }
    }
}
