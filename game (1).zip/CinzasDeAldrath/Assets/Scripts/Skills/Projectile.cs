using System.Collections.Generic;
using UnityEngine;
using CinzasDeAldrath.Audio;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.Visual;

namespace CinzasDeAldrath.Skills
{
    /// <summary>
    /// Projétil genérico. O movimento usa CircleCast por quadro (não atravessa paredes finas)
    /// e o dano em área é aplicado uma única vez por alvo na explosão.
    /// </summary>
    public class Projectile : MonoBehaviour
    {
        public struct LaunchData
        {
            public Team team;
            public float damage;
            public DamageType type;
            public float speed;
            public float maxDistance;
            public float areaRadius;
            public Vector2 direction;
            public GameObject impactPrefab;
            public float knockback;
            public GameObject source;
        }

        [SerializeField] float radius = 0.22f;

        static readonly RaycastHit2D[] Hits = new RaycastHit2D[8];
        static readonly Collider2D[] Overlaps = new Collider2D[32];
        static readonly List<Health> Victims = new List<Health>(8);
        static ContactFilter2D _filter;
        static bool _filterReady;

        LaunchData _d;
        float _traveled;
        bool _active;

        static ContactFilter2D Filter
        {
            get
            {
                if (!_filterReady)
                {
                    _filter = new ContactFilter2D();
                    _filter.useTriggers = false;
                    _filterReady = true;
                }
                return _filter;
            }
        }

        void OnEnable()
        {
            _active = false;
        }

        public void Launch(LaunchData data)
        {
            _d = data;
            _d.direction = data.direction.sqrMagnitude > 0.0001f ? data.direction.normalized : Vector2.right;
            _traveled = 0f;
            _active = true;
            float angle = Mathf.Atan2(_d.direction.y, _d.direction.x) * Mathf.Rad2Deg;
            transform.rotation = Quaternion.Euler(0f, 0f, angle);
        }

        void Update()
        {
            if (!_active) return;

            Vector2 pos = transform.position;
            float remaining = _d.maxDistance - _traveled;
            if (remaining <= 0.001f)
            {
                Explode(pos, null);
                return;
            }

            float step = Mathf.Min(_d.speed * Time.deltaTime, remaining);
            int n = Physics2D.CircleCast(pos, radius, _d.direction, Filter, Hits, step);

            int bestIndex = -1;
            float bestDistance = float.MaxValue;
            Health bestHealth = null;

            for (int i = 0; i < n; i++)
            {
                var col = Hits[i].collider;
                if (col == null) continue;
                var h = col.GetComponentInParent<Health>();
                if (h != null && (h.Team == _d.team || h.IsDead)) continue; // atravessa aliados e mortos
                if (Hits[i].distance < bestDistance)
                {
                    bestDistance = Hits[i].distance;
                    bestIndex = i;
                    bestHealth = h;
                }
            }

            if (bestIndex >= 0)
            {
                Explode(Hits[bestIndex].centroid, bestHealth);
                return;
            }

            transform.position = pos + _d.direction * step;
            _traveled += step;
        }

        void Explode(Vector2 point, Health direct)
        {
            _active = false;
            Victims.Clear();
            if (direct != null) Victims.Add(direct);

            if (_d.areaRadius > 0f)
            {
                int n = Physics2D.OverlapCircle(point, _d.areaRadius, Filter, Overlaps);
                for (int i = 0; i < n; i++)
                {
                    var h = Overlaps[i].GetComponentInParent<Health>();
                    if (h == null || h.IsDead || h.Team == _d.team || Victims.Contains(h)) continue;
                    Victims.Add(h);
                }
            }

            for (int i = 0; i < Victims.Count; i++)
            {
                var h = Victims[i];
                Vector2 away = h.CenterPosition - point;
                float side = Mathf.Sign(away.x);
                var info = new DamageInfo(
                    _d.damage, _d.type, _d.team,
                    new Vector2(side * _d.knockback, _d.knockback * 0.5f), _d.source);
                h.TakeDamage(info);
            }

            if (_d.impactPrefab != null)
            {
                var fx = PoolManager.Spawn(_d.impactPrefab, point, Quaternion.identity);
                var flash = fx.GetComponent<ImpactFlash>();
                if (flash != null) flash.Play(_d.areaRadius > 0f ? _d.areaRadius : 0.6f);
            }

            SfxPlayer.Play(ProceduralSfx.Explosion, 0.7f);
            PoolManager.Despawn(gameObject);
        }
    }
}
