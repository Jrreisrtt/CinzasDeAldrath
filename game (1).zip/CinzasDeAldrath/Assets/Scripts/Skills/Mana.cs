using System;
using UnityEngine;

namespace CinzasDeAldrath.Skills
{
    public class Mana : MonoBehaviour
    {
        [SerializeField] float maxMana = 50f;
        [SerializeField] float regenPerSecond = 4f;

        public event Action<Mana> Changed;

        public float Current { get; private set; }
        public float Max => maxMana;

        void Awake()
        {
            Current = maxMana;
        }

        void Update()
        {
            if (Current >= maxMana) return;
            Current = Mathf.Min(maxMana, Current + regenPerSecond * Time.deltaTime);
            Changed?.Invoke(this);
        }

        public bool CanSpend(float amount) => Current >= amount;

        public bool Spend(float amount)
        {
            if (Current < amount) return false;
            Current -= amount;
            Changed?.Invoke(this);
            return true;
        }

        public void SetMax(float newMax, bool refill)
        {
            maxMana = newMax;
            Current = refill ? maxMana : Mathf.Min(Current, maxMana);
            Changed?.Invoke(this);
        }
    }
}
