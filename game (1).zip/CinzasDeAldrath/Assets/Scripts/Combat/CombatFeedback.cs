using UnityEngine;
using CinzasDeAldrath.Audio;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.Progression;
using CinzasDeAldrath.World;

namespace CinzasDeAldrath.Combat
{
    /// <summary>Reage a eventos de combate com números de dano, sons e tremor de câmera.</summary>
    public class CombatFeedback : MonoBehaviour
    {
        [SerializeField] DamagePopup popupPrefab;

        PlayerProgress _progress;

        void OnEnable()
        {
            Health.AnyDamaged += OnAnyDamaged;
            GameEvents.EnemyKilled += OnEnemyKilled;
        }

        void OnDisable()
        {
            Health.AnyDamaged -= OnAnyDamaged;
            GameEvents.EnemyKilled -= OnEnemyKilled;
        }

        void Start()
        {
            _progress = FindFirstObjectByType<PlayerProgress>();
            if (_progress != null) _progress.LeveledUp += OnLevelUp;
        }

        void OnDestroy()
        {
            if (_progress != null) _progress.LeveledUp -= OnLevelUp;
        }

        void OnAnyDamaged(Health target, float amount, DamageInfo info)
        {
            Color color;
            if (target.Team == Team.Player) color = new Color(1f, 0.35f, 0.3f);
            else if (info.isCritical) color = new Color(1f, 0.9f, 0.2f);
            else if (info.type == DamageType.Fire) color = new Color(1f, 0.6f, 0.2f);
            else color = Color.white;

            string text = Mathf.RoundToInt(amount).ToString() + (info.isCritical ? "!" : "");
            Popup(target.CenterPosition + Vector2.up * 0.9f, text, color, info.isCritical ? 1.3f : 1f);

            SfxPlayer.Play(ProceduralSfx.Hit, 0.5f);
            if (CameraFollow.Instance != null)
                CameraFollow.Instance.Shake(target.Team == Team.Player ? 0.15f : 0.05f, 0.2f);
        }

        void OnEnemyKilled(EnemyKilledInfo info)
        {
            Popup(info.position + Vector2.up * 1.4f, "+" + info.xp + " XP", new Color(0.7f, 1f, 0.5f), 1f);
        }

        void OnLevelUp(int level)
        {
            if (_progress != null)
                Popup((Vector2)_progress.transform.position + Vector2.up * 2.2f, "NIVEL " + level + "!", new Color(1f, 0.9f, 0.3f), 1.6f);
            SfxPlayer.Play(ProceduralSfx.LevelUp, 0.7f);
        }

        void Popup(Vector2 position, string text, Color color, float scale)
        {
            if (popupPrefab == null) return;
            var go = PoolManager.Spawn(popupPrefab.gameObject, position, Quaternion.identity);
            var popup = go.GetComponent<DamagePopup>();
            if (popup != null) popup.Show(text, color, scale);
        }
    }
}
