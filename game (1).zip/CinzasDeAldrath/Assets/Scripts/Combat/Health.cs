using System;
using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Combat
{
    /// <summary>
    /// Vida, defesa, resistências e invulnerabilidade temporária. Usado por jogador e inimigos.
    /// Fórmula: dano = bruto * 100/(100+defesa) * (1 - resistência), arredondado, mínimo 1.
    /// </summary>
    [DisallowMultipleComponent]
    public class Health : MonoBehaviour
    {
        [SerializeField] Team team = Team.Enemy;
        [SerializeField] float maxHealth = 100f;
        [SerializeField] float defense;
        [SerializeField] float invulnerabilityTime;
        [SerializeField] Resistances resistances = new Resistances();

        public static event Action<Health, float, DamageInfo> AnyDamaged;
        public static event Action<Health, DamageInfo> AnyDied;

        public event Action<Health, float, DamageInfo> Damaged;
        public event Action<Health, DamageInfo> Died;
        public event Action<Health> Changed;

        Collider2D _collider;
        float _invulnerableUntil;

        public float Current { get; private set; }
        public float Max => maxHealth;
        public float Defense => defense;
        public Team Team => team;
        public bool IsDead => Current <= 0f;

        public Vector2 CenterPosition =>
            _collider != null ? (Vector2)_collider.bounds.center : (Vector2)transform.position;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            AnyDamaged = null;
            AnyDied = null;
        }

        void Awake()
        {
            _collider = GetComponent<Collider2D>();
            Current = maxHealth;
        }

        public void Configure(Team newTeam, float max, float newDefense, Resistances newResistances, float invulnerability)
        {
            team = newTeam;
            maxHealth = max;
            defense = newDefense;
            if (newResistances != null) resistances = newResistances;
            invulnerabilityTime = invulnerability;
            Current = maxHealth;
            Changed?.Invoke(this);
        }

        public void SetMax(float newMax, bool refill)
        {
            maxHealth = newMax;
            Current = refill ? maxHealth : Mathf.Min(Current, maxHealth);
            Changed?.Invoke(this);
        }

        public void Heal(float amount)
        {
            if (IsDead) return;
            Current = Mathf.Min(maxHealth, Current + amount);
            Changed?.Invoke(this);
        }

        public static float CalculateDamage(float raw, float defense, float resistance)
        {
            if (raw <= 0f || resistance >= 1f) return 0f;
            float afterDefense = raw * 100f / (100f + Mathf.Max(0f, defense));
            float final = afterDefense * (1f - Mathf.Clamp(resistance, -1f, 1f));
            return Mathf.Max(1f, Mathf.Round(final));
        }

        /// <summary>Retorna true se o dano foi realmente aplicado.</summary>
        public bool TakeDamage(DamageInfo info)
        {
            if (IsDead) return false;
            if (info.sourceTeam == team) return false;
            if (Time.time < _invulnerableUntil) return false;

            float final = CalculateDamage(info.amount, defense, resistances.Get(info.type));
            if (final <= 0f) return false;

            Current = Mathf.Max(0f, Current - final);
            _invulnerableUntil = Time.time + invulnerabilityTime;

            Damaged?.Invoke(this, final, info);
            AnyDamaged?.Invoke(this, final, info);
            Changed?.Invoke(this);

            if (Current <= 0f)
            {
                Died?.Invoke(this, info);
                AnyDied?.Invoke(this, info);
            }
            return true;
        }

        public void Kill()
        {
            if (IsDead) return;
            Current = 0f;
            var info = new DamageInfo(0f, DamageType.Physical, Team.Neutral, Vector2.zero);
            Changed?.Invoke(this);
            Died?.Invoke(this, info);
            AnyDied?.Invoke(this, info);
        }
    }
}
