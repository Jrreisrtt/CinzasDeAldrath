using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Combat
{
    public static class TargetFinder
    {
        static readonly Collider2D[] Buffer = new Collider2D[32];
        static ContactFilter2D _filter;
        static bool _ready;

        /// <summary>Alvo vivo mais próximo de outro time dentro do raio. Opcionalmente só à frente.</summary>
        public static Health FindNearestEnemy(Vector2 origin, float radius, Team ownTeam, int facing, bool onlyInFront)
        {
            if (!_ready)
            {
                _filter = new ContactFilter2D();
                _filter.useTriggers = false;
                _ready = true;
            }

            int count = Physics2D.OverlapCircle(origin, radius, _filter, Buffer);
            Health best = null;
            float bestSqr = float.MaxValue;

            for (int i = 0; i < count; i++)
            {
                var h = Buffer[i].GetComponentInParent<Health>();
                if (h == null || h.IsDead || h.Team == ownTeam || h.Team == Team.Neutral) continue;

                Vector2 delta = h.CenterPosition - origin;
                if (onlyInFront && Mathf.Abs(delta.x) > 0.1f && Mathf.Sign(delta.x) != facing) continue;

                float sqr = delta.sqrMagnitude;
                if (sqr < bestSqr)
                {
                    bestSqr = sqr;
                    best = h;
                }
            }
            return best;
        }
    }
}
