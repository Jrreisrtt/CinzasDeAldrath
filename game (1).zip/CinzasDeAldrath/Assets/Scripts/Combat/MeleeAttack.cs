using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Combat
{
    /// <summary>
    /// Ataque corpo a corpo por caixa de acerto. A checagem acontece uma única vez por golpe
    /// e cada alvo só é atingido uma vez, então ficar encostado não repete o dano.
    /// </summary>
    [RequireComponent(typeof(Health))]
    public class MeleeAttack : MonoBehaviour
    {
        [SerializeField] float damage = 14f;
        [SerializeField] DamageType damageType = DamageType.Physical;
        [SerializeField] float cooldown = 0.35f;
        [SerializeField] float windup = 0.06f;
        [SerializeField] float recovery = 0.12f;
        [SerializeField] Vector2 boxSize = new Vector2(1.4f, 1.2f);
        [SerializeField] Vector2 boxOffset = new Vector2(0.9f, 0f);
        [SerializeField] Vector2 knockback = new Vector2(5f, 3f);
        [SerializeField, Range(0f, 1f)] float critChance = 0.05f;
        [SerializeField] float critMultiplier = 1.5f;
        [SerializeField] Transform slashVisual;
        [SerializeField] float slashDuration = 0.09f;

        static readonly Collider2D[] Buffer = new Collider2D[16];
        static ContactFilter2D _filter;
        static bool _filterReady;

        Health _health;
        float _nextAttackTime;
        readonly HashSet<Health> _alreadyHit = new HashSet<Health>();

        /// <summary>Disparado no início do golpe, com a duração da preparação (windup).</summary>
        public event Action<float> WindupStarted;
        /// <summary>Disparado no instante em que a caixa de acerto é checada.</summary>
        public event Action Swung;

        public bool IsAttacking { get; private set; }

        public float Damage
        {
            get => damage;
            set => damage = value;
        }

        static ContactFilter2D Filter
        {
            get
            {
                if (!_filterReady)
                {
                    _filter = new ContactFilter2D();
                    _filter.useTriggers = false;
                    _filterReady = true;
                }
                return _filter;
            }
        }

        void Awake()
        {
            _health = GetComponent<Health>();
            if (slashVisual != null) slashVisual.gameObject.SetActive(false);
        }

        void OnDisable()
        {
            StopAllCoroutines();
            IsAttacking = false;
            if (slashVisual != null) slashVisual.gameObject.SetActive(false);
        }

        public void Configure(float newDamage, float newCooldown, float newWindup, Vector2 newBoxSize, Vector2 newBoxOffset, Vector2 newKnockback, float newCritChance)
        {
            damage = newDamage;
            cooldown = newCooldown;
            windup = newWindup;
            boxSize = newBoxSize;
            boxOffset = newBoxOffset;
            knockback = newKnockback;
            critChance = newCritChance;
        }

        public bool TryAttack(int facing)
        {
            if (IsAttacking || Time.time < _nextAttackTime || _health.IsDead) return false;
            StartCoroutine(Swing(facing >= 0 ? 1 : -1));
            return true;
        }

        IEnumerator Swing(int facing)
        {
            IsAttacking = true;
            _nextAttackTime = Time.time + cooldown;
            WindupStarted?.Invoke(windup);

            if (windup > 0f) yield return new WaitForSeconds(windup);

            if (!_health.IsDead)
            {
                Swung?.Invoke();
                if (slashVisual != null) StartCoroutine(ShowSlash(facing));
                ApplyHits(facing);
            }

            if (recovery > 0f) yield return new WaitForSeconds(recovery);
            IsAttacking = false;
        }

        void ApplyHits(int facing)
        {
            Vector2 center = (Vector2)transform.position + new Vector2(boxOffset.x * facing, boxOffset.y);
            int count = Physics2D.OverlapBox(center, boxSize, 0f, Filter, Buffer);
            _alreadyHit.Clear();

            for (int i = 0; i < count; i++)
            {
                var target = Buffer[i].GetComponentInParent<Health>();
                if (target == null || target == _health || target.IsDead) continue;
                if (target.Team == _health.Team) continue;
                if (!_alreadyHit.Add(target)) continue;

                bool crit = UnityEngine.Random.value < critChance;
                float amount = crit ? damage * critMultiplier : damage;
                var info = new DamageInfo(
                    amount, damageType, _health.Team,
                    new Vector2(knockback.x * facing, knockback.y), gameObject, crit);
                target.TakeDamage(info);
            }
        }

        IEnumerator ShowSlash(int facing)
        {
            slashVisual.localPosition = new Vector3(boxOffset.x * facing, boxOffset.y, 0f);
            var s = slashVisual.localScale;
            slashVisual.localScale = new Vector3(Mathf.Abs(s.x) * facing, s.y, s.z);
            slashVisual.gameObject.SetActive(true);
            yield return new WaitForSeconds(slashDuration);
            slashVisual.gameObject.SetActive(false);
        }

        void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireCube(transform.position + (Vector3)boxOffset, boxSize);
        }
    }
}
