using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Combat
{
    /// <summary>Aplica empurrão e um breve atordoamento quando o dono recebe dano.</summary>
    [RequireComponent(typeof(Rigidbody2D), typeof(Health))]
    public class KnockbackReceiver : MonoBehaviour
    {
        [SerializeField] float stunDuration = 0.18f;
        [SerializeField, Range(0f, 1f)] float resistance;

        Rigidbody2D _rb;
        Health _health;
        float _stunUntil;

        public bool IsStunned => Time.time < _stunUntil;

        void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();
            _health = GetComponent<Health>();
        }

        void OnEnable()
        {
            if (_health == null) _health = GetComponent<Health>();
            _health.Damaged += OnDamaged;
        }

        void OnDisable()
        {
            if (_health != null) _health.Damaged -= OnDamaged;
        }

        void OnDamaged(Health h, float finalDamage, DamageInfo info)
        {
            _stunUntil = Time.time + stunDuration;
            if (_rb != null && _rb.simulated)
                _rb.velocity = info.knockback * (1f - resistance);
        }
    }
}
