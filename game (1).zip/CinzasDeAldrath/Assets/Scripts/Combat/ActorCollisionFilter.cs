using System.Collections.Generic;
using UnityEngine;

namespace CinzasDeAldrath.Combat
{
    /// <summary>
    /// Faz jogador e inimigos não se empurrarem fisicamente (sem depender de camadas).
    /// Chão e paredes continuam colidindo normalmente.
    /// </summary>
    [RequireComponent(typeof(Collider2D))]
    public class ActorCollisionFilter : MonoBehaviour
    {
        static readonly List<Collider2D> Actors = new List<Collider2D>();
        Collider2D _col;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            Actors.Clear();
        }

        void OnEnable()
        {
            _col = GetComponent<Collider2D>();
            for (int i = Actors.Count - 1; i >= 0; i--)
            {
                var other = Actors[i];
                if (other == null) { Actors.RemoveAt(i); continue; }
                Physics2D.IgnoreCollision(_col, other, true);
            }
            Actors.Add(_col);
        }

        void OnDisable()
        {
            Actors.Remove(_col);
        }
    }
}
