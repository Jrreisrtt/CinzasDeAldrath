using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Combat
{
    /// <summary>Número de dano flutuante (TextMesh), reaproveitado via PoolManager.</summary>
    [RequireComponent(typeof(TextMesh))]
    public class DamagePopup : MonoBehaviour
    {
        [SerializeField] float lifetime = 0.8f;
        [SerializeField] float riseSpeed = 2.2f;

        TextMesh _text;
        float _t;
        Color _color;
        Vector3 _velocity;

        void Awake()
        {
            _text = GetComponent<TextMesh>();
        }

        public void Show(string text, Color color, float scale)
        {
            if (_text == null) _text = GetComponent<TextMesh>();
            _text.text = text;
            _color = color;
            _text.color = color;
            transform.localScale = Vector3.one * scale;
            _t = 0f;
            _velocity = new Vector3(UnityEngine.Random.Range(-0.6f, 0.6f), riseSpeed, 0f);
        }

        void Update()
        {
            _t += Time.deltaTime;
            transform.position += _velocity * Time.deltaTime;
            _velocity.y = Mathf.Max(0f, _velocity.y - 4f * Time.deltaTime);

            float fadeStart = lifetime * 0.5f;
            var c = _color;
            c.a = 1f - Mathf.Clamp01((_t - fadeStart) / (lifetime - fadeStart));
            _text.color = c;

            if (_t >= lifetime) PoolManager.Despawn(gameObject);
        }
    }
}
