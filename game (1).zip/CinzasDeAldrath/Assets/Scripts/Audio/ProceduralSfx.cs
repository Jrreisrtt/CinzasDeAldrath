using UnityEngine;

namespace CinzasDeAldrath.Audio
{
    /// <summary>
    /// Efeitos sonoros sintetizados em código (originais, sem arquivos externos).
    /// Servem como placeholder até existirem sons de verdade em Assets/Audio.
    /// </summary>
    public static class ProceduralSfx
    {
        const int Rate = 22050;
        static AudioClip _jump, _hit, _swing, _cast, _explosion, _levelUp;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            _jump = _hit = _swing = _cast = _explosion = _levelUp = null;
        }

        public static AudioClip Jump => _jump != null ? _jump : (_jump = Make("jump", 0.14f, 280f, 620f, 0.30f, 0f));
        public static AudioClip Hit => _hit != null ? _hit : (_hit = Make("hit", 0.10f, 180f, 90f, 0.40f, 0.5f));
        public static AudioClip Swing => _swing != null ? _swing : (_swing = Make("swing", 0.12f, 500f, 220f, 0.20f, 0.6f));
        public static AudioClip Cast => _cast != null ? _cast : (_cast = Make("cast", 0.28f, 220f, 700f, 0.30f, 0.25f));
        public static AudioClip Explosion => _explosion != null ? _explosion : (_explosion = Make("explosion", 0.35f, 120f, 40f, 0.50f, 0.7f));
        public static AudioClip LevelUp => _levelUp != null ? _levelUp : (_levelUp = Make("levelup", 0.40f, 400f, 900f, 0.30f, 0f));

        static AudioClip Make(string name, float duration, float f0, float f1, float volume, float noise)
        {
            int n = Mathf.Max(1, (int)(Rate * duration));
            var data = new float[n];
            float phase = 0f;
            uint seed = 12345u;
            for (int i = 0; i < n; i++)
            {
                float t = i / (float)n;
                float f = Mathf.Lerp(f0, f1, t);
                phase += 2f * Mathf.PI * f / Rate;
                seed = seed * 1664525u + 1013904223u;
                float rnd = ((seed >> 8) & 0xFFFF) / 32767.5f - 1f;
                float s = Mathf.Sin(phase) * (1f - noise) + rnd * noise;
                float env = (1f - t) * (1f - t);
                data[i] = s * env * volume;
            }
            var clip = AudioClip.Create(name, n, 1, Rate, false);
            clip.SetData(data, 0);
            return clip;
        }
    }

    public static class SfxPlayer
    {
        public static float Volume = 1f;
        static AudioSource _source;

        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.SubsystemRegistration)]
        static void ResetStatics()
        {
            _source = null;
        }

        public static void Play(AudioClip clip, float volume = 1f)
        {
            if (clip == null) return;
            if (_source == null)
            {
                var go = new GameObject("[Sfx]");
                Object.DontDestroyOnLoad(go);
                _source = go.AddComponent<AudioSource>();
                _source.playOnAwake = false;
                _source.spatialBlend = 0f;
            }
            _source.PlayOneShot(clip, volume * Volume);
        }
    }
}
