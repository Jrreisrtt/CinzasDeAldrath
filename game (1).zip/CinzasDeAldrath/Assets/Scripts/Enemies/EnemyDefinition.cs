using UnityEngine;
using CinzasDeAldrath.Core;

namespace CinzasDeAldrath.Enemies
{
    /// <summary>Dados de um tipo de inimigo. Novos inimigos = novos assets, sem mexer no código.</summary>
    [CreateAssetMenu(menuName = "Cinzas/Enemy Definition", fileName = "NovoInimigo")]
    public class EnemyDefinition : ScriptableObject
    {
        public string enemyId = "enemy";
        public string displayName = "Inimigo";

        [Header("Atributos")]
        public float maxHealth = 40f;
        public float defense = 0f;
        public Resistances resistances = new Resistances();

        [Header("Comportamento")]
        public float moveSpeed = 2.5f;
        public float detectRange = 8f;
        public float attackRange = 1.2f;

        [Header("Ataque corpo a corpo")]
        public float attackDamage = 8f;
        public float attackCooldown = 1.3f;
        public float attackWindup = 0.4f;
        public Vector2 attackBoxSize = new Vector2(1.1f, 0.9f);
        public Vector2 attackBoxOffset = new Vector2(0.85f, 0f);
        public Vector2 attackKnockback = new Vector2(5f, 3f);

        [Header("Recompensas")]
        public int xpReward = 15;
        public int goldReward = 5;

        [Header("Visual (placeholder)")]
        public Color tint = new Color(0.85f, 0.35f, 0.3f);
    }
}
