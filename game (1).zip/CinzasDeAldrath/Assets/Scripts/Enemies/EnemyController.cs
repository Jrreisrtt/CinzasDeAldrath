using UnityEngine;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.PlayerControl;
using CinzasDeAldrath.Visual;

namespace CinzasDeAldrath.Enemies
{
    /// <summary>
    /// Inimigo corpo a corpo: fica parado, persegue ao detectar o jogador, ataca ao alcance.
    /// Todos os números vêm do EnemyDefinition.
    /// </summary>
    [RequireComponent(typeof(Rigidbody2D), typeof(Health), typeof(MeleeAttack))]
    public class EnemyController : MonoBehaviour
    {
        [SerializeField] EnemyDefinition definition;
        [SerializeField] float removeDelay = 1f;

        Rigidbody2D _rb;
        Health _health;
        MeleeAttack _melee;
        KnockbackReceiver _knock;
        ActorVisual _visual;
        Transform _target;
        Health _targetHealth;
        int _facing = -1;

        public EnemyDefinition Definition => definition;

        void Awake()
        {
            _rb = GetComponent<Rigidbody2D>();
            _health = GetComponent<Health>();
            _melee = GetComponent<MeleeAttack>();
            _knock = GetComponent<KnockbackReceiver>();
            _visual = GetComponent<ActorVisual>();
            ApplyDefinition();
        }

        void ApplyDefinition()
        {
            if (definition == null) return;
            _health.Configure(Team.Enemy, definition.maxHealth, definition.defense, definition.resistances, 0f);
            _melee.Configure(definition.attackDamage, definition.attackCooldown, definition.attackWindup,
                definition.attackBoxSize, definition.attackBoxOffset, definition.attackKnockback, 0f);
            if (_visual != null) _visual.SetBaseColor(definition.tint);
        }

        void OnEnable()
        {
            _health.Died += OnDied;
        }

        void OnDisable()
        {
            _health.Died -= OnDied;
        }

        void Start()
        {
            FindTarget();
        }

        void FindTarget()
        {
            var player = FindFirstObjectByType<PlayerController>();
            if (player == null) return;
            _target = player.transform;
            _targetHealth = player.Health;
        }

        void Update()
        {
            if (_visual != null)
            {
                _visual.Facing = _facing;
                float speed01 = definition != null && definition.moveSpeed > 0f
                    ? Mathf.Abs(_rb.velocity.x) / definition.moveSpeed : 0f;
                _visual.SetMotion(speed01, true);
            }
        }

        void FixedUpdate()
        {
            if (definition == null) return;
            if (_health.IsDead) { SetVelocityX(0f); return; }
            if (_knock != null && _knock.IsStunned) return;

            if (_target == null)
            {
                FindTarget();
                if (_target == null) { SetVelocityX(0f); return; }
            }
            if (_targetHealth == null || _targetHealth.IsDead) { SetVelocityX(0f); return; }

            Vector2 delta = _target.position - transform.position;
            float dx = Mathf.Abs(delta.x);
            float dy = Mathf.Abs(delta.y);

            bool inAttackRange = dx <= definition.attackRange && dy <= 1.3f;
            bool detected = dx <= definition.detectRange && dy <= definition.detectRange * 0.6f;

            if (inAttackRange)
            {
                SetVelocityX(0f);
                _facing = delta.x >= 0f ? 1 : -1;
                if (!_melee.IsAttacking) _melee.TryAttack(_facing);
            }
            else if (detected && !_melee.IsAttacking)
            {
                _facing = delta.x >= 0f ? 1 : -1;
                SetVelocityX(_facing * definition.moveSpeed);
            }
            else
            {
                SetVelocityX(0f);
            }
        }

        void SetVelocityX(float x)
        {
            var v = _rb.velocity;
            v.x = x;
            _rb.velocity = v;
        }

        void OnDied(Health h, DamageInfo info)
        {
            if (definition != null)
            {
                GameEvents.RaiseEnemyKilled(new EnemyKilledInfo
                {
                    enemyId = definition.enemyId,
                    xp = definition.xpReward,
                    gold = definition.goldReward,
                    position = transform.position
                });
            }

            var col = GetComponent<Collider2D>();
            if (col != null) col.enabled = false;
            _rb.velocity = Vector2.zero;
            _rb.simulated = false;
            Destroy(gameObject, removeDelay);
        }
    }
}
