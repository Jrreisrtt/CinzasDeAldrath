using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.PlayerControl;
using CinzasDeAldrath.UI;
using CinzasDeAldrath.World;

namespace CinzasDeAldrath.EditorTools
{
    /// <summary>
    /// Ponto de entrada para compilar sem interface gráfica (GitHub Actions / game-ci):
    ///   -executeMethod CinzasDeAldrath.EditorTools.BatchBuild.Build
    /// Monta o projeto, valida as referências essenciais e gera o APK. Em caso de falha,
    /// termina com um código de saída identificável e uma linha "[CinzasBuild] ERRO ..." no log.
    /// Observação: não importa "System" de propósito, para não haver ambiguidade de "Object".
    /// </summary>
    public static class BatchBuild
    {
        public const int ExitUnexpected = 1;
        public const int ExitSetupFailed = 10;
        public const int ExitValidationFailed = 11;
        public const int ExitBuildFailed = 12;
        public const int ExitNoOutput = 13;

        public static void Build()
        {
            try
            {
                Debug.Log("[CinzasBuild] 1/4 Montando recursos e cena...");
                try
                {
                    ProjectBootstrapper.SetupAll();
                }
                catch (System.Exception e)
                {
                    Fail(ExitSetupFailed, "Falha ao montar o projeto: " + e);
                    return;
                }

                Debug.Log("[CinzasBuild] 2/4 Validando referências essenciais...");
                var problems = Validate();
                if (problems.Count > 0)
                {
                    Fail(ExitValidationFailed, "Validação falhou:\n - " + string.Join("\n - ", problems));
                    return;
                }

                Debug.Log("[CinzasBuild] 3/4 Compilando APK...");
                string dir = GetArg("-customBuildPath", "build/Android");
                string name = GetArg("-customBuildName", "CinzasDeAldrath");
                Directory.CreateDirectory(dir);
                string apk = Path.Combine(dir, name + ".apk");

                EditorUserBuildSettings.buildAppBundle = false;
                EditorUserBuildSettings.androidBuildSystem = AndroidBuildSystem.Gradle;
                PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;

                var options = new BuildPlayerOptions
                {
                    scenes = new[] { ProjectBootstrapper.ScenePath },
                    locationPathName = apk,
                    target = BuildTarget.Android,
                    options = BuildOptions.Development
                };
                BuildReport report = BuildPipeline.BuildPlayer(options);

                Debug.Log("[CinzasBuild] Resultado: " + report.summary.result +
                          " | erros: " + report.summary.totalErrors +
                          " | avisos: " + report.summary.totalWarnings);

                if (report.summary.result != BuildResult.Succeeded)
                {
                    Fail(ExitBuildFailed, "A compilação Android falhou (" + report.summary.result + ").");
                    return;
                }

                Debug.Log("[CinzasBuild] 4/4 Conferindo o arquivo...");
                var info = new FileInfo(apk);
                if (!info.Exists || info.Length == 0)
                {
                    Fail(ExitNoOutput, "APK não encontrado ou vazio em " + apk);
                    return;
                }

                Debug.Log("[CinzasBuild] OK: " + apk + " (" + (info.Length / 1024 / 1024) + " MB)");
                EditorApplication.Exit(0);
            }
            catch (System.Exception e)
            {
                Fail(ExitUnexpected, "Exceção inesperada: " + e);
            }
        }

        static void Fail(int code, string message)
        {
            Debug.LogError("[CinzasBuild] ERRO (código " + code + "): " + message);
            EditorApplication.Exit(code);
        }

        static string GetArg(string flag, string fallback)
        {
            var args = System.Environment.GetCommandLineArgs();
            for (int i = 0; i < args.Length - 1; i++)
                if (args[i] == flag && !string.IsNullOrEmpty(args[i + 1])) return args[i + 1];
            return fallback;
        }

        static List<string> Validate()
        {
            var problems = new List<string>();

            string[] requiredAssets =
            {
                ProjectBootstrapper.ScenePath,
                "Assets/Prefabs/Player.prefab",
                "Assets/Prefabs/AshGrub.prefab",
                "Assets/Prefabs/Fireball.prefab",
                "Assets/Prefabs/FireImpact.prefab",
                "Assets/Prefabs/DamagePopup.prefab",
                "Assets/ScriptableObjects/Skills/Fireball.asset",
                "Assets/ScriptableObjects/Enemies/AshGrub.asset"
            };
            foreach (var path in requiredAssets)
                if (AssetDatabase.LoadMainAssetAtPath(path) == null) problems.Add("Asset ausente: " + path);

            bool inBuild = false;
            foreach (var s in EditorBuildSettings.scenes)
                if (s.enabled && s.path == ProjectBootstrapper.ScenePath) inBuild = true;
            if (!inBuild) problems.Add("A cena TestArena não está na lista de cenas de compilação.");

            if (problems.Count > 0) return problems;

            EditorSceneManager.OpenScene(ProjectBootstrapper.ScenePath, OpenSceneMode.Single);

            var player = Object.FindFirstObjectByType<PlayerController>();
            var hud = Object.FindFirstObjectByType<HudController>();
            var manager = Object.FindFirstObjectByType<GameManager>();
            var follow = Object.FindFirstObjectByType<CameraFollow>();
            var feedback = Object.FindFirstObjectByType<CombatFeedback>();
            var spawn = Object.FindFirstObjectByType<EnemySpawnPoint>();

            if (player == null) problems.Add("PlayerController não encontrado na cena.");
            if (hud == null) problems.Add("HudController não encontrado na cena.");
            if (manager == null) problems.Add("GameManager não encontrado na cena.");
            if (follow == null) problems.Add("CameraFollow não encontrado na cena.");
            if (feedback == null) problems.Add("CombatFeedback não encontrado na cena.");
            if (spawn == null) problems.Add("Nenhum EnemySpawnPoint na cena.");
            if (Object.FindFirstObjectByType<EventSystem>() == null) problems.Add("EventSystem ausente (botões de toque não funcionariam).");
            if (Camera.main == null) problems.Add("Câmera principal ausente.");

            if (hud != null)
            {
                if (hud.playerHealth == null) problems.Add("HUD: playerHealth não ligado.");
                if (hud.playerMana == null) problems.Add("HUD: playerMana não ligado.");
                if (hud.progress == null) problems.Add("HUD: progress não ligado.");
                if (hud.caster == null) problems.Add("HUD: caster não ligado.");
                if (hud.healthFill == null || hud.manaFill == null || hud.xpFill == null) problems.Add("HUD: barras não ligadas.");
                if (hud.skillButtons == null || hud.skillButtons.Length != 3) problems.Add("HUD: botões de habilidade incompletos.");
            }

            if (player != null)
            {
                var caster = player.GetComponent<CinzasDeAldrath.Skills.SkillCaster>();
                if (caster == null || caster.GetSkill(0) == null) problems.Add("Jogador sem habilidade no slot 1 (bola de fogo).");
            }

            return problems;
        }
    }
}
