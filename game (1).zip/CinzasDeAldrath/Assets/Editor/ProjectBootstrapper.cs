using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using CinzasDeAldrath.Combat;
using CinzasDeAldrath.Core;
using CinzasDeAldrath.Enemies;
using CinzasDeAldrath.PlayerControl;
using CinzasDeAldrath.Progression;
using CinzasDeAldrath.Skills;
using CinzasDeAldrath.UI;
using CinzasDeAldrath.Visual;
using CinzasDeAldrath.World;

namespace CinzasDeAldrath.EditorTools
{
    /// <summary>
    /// Cria tudo que o protótipo precisa a partir dos scripts: sprites placeholder, assets de dados,
    /// prefabs, a cena TestArena (com HUD e controles de toque) e as configurações de Android.
    /// Menu: Cinzas de Aldrath > 1. Configurar projeto e criar arena de teste
    /// </summary>
    public static class ProjectBootstrapper
    {
        public const string ScenePath = "Assets/Scenes/TestArena.unity";
        const string ApkPath = "Builds/CinzasDeAldrath-teste.apk";

        static Sprite _square;
        static Sprite _circle;
        static PhysicsMaterial2D _noFriction;
        static Font _font;

        [MenuItem("Cinzas de Aldrath/1. Configurar projeto e criar arena de teste")]
        public static void SetupAll()
        {
            if (!Application.isBatchMode && File.Exists(ScenePath) &&
                !EditorUtility.DisplayDialog("Cinzas de Aldrath",
                    "A cena TestArena e os prefabs gerados serão recriados. Continuar?", "Continuar", "Cancelar"))
                return;

            EnsureFolders();
            ConfigurePlayerSettings();

            _square = MakeSprite("Square", 32, false, 32f);
            _circle = MakeSprite("Circle", 64, true, 64f);
            _noFriction = MakeNoFrictionMaterial();
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (_font == null) _font = Font.CreateDynamicFontFromOSFont("Arial", 16);

            var popup = CreatePopupPrefab();
            var projectile = CreateFireballPrefab();
            var impact = CreateImpactPrefab();
            var fireball = CreateFireballSkill(projectile, impact);
            var grub = CreateEnemyDefinition();
            var enemyPrefab = CreateEnemyPrefab(grub);
            var playerPrefab = CreatePlayerPrefab(fireball);

            CreateScene(playerPrefab, enemyPrefab, popup);

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            Debug.Log("[Cinzas] Projeto configurado: " + ScenePath);
            if (!Application.isBatchMode)
                EditorUtility.DisplayDialog("Cinzas de Aldrath",
                    "Projeto configurado.\n\nAbra Assets/Scenes/TestArena e aperte Play.\n" +
                    "Teclado: A/D mover, Espaço saltar, J atacar, K ou 1 bola de fogo.", "OK");
        }

        [MenuItem("Cinzas de Aldrath/2. Gerar APK de teste (Android)")]
        public static void BuildApk()
        {
            if (!File.Exists(ScenePath))
            {
                EditorUtility.DisplayDialog("Cinzas de Aldrath", "Execute primeiro o passo 1 (criar a arena de teste).", "OK");
                return;
            }
            Directory.CreateDirectory("Builds");
            var options = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = ApkPath,
                target = BuildTarget.Android,
                options = BuildOptions.Development
            };
            BuildReport report = BuildPipeline.BuildPlayer(options);
            Debug.Log("Build Android: " + report.summary.result + " -> " + ApkPath);
        }

        // ---------- Configuração ----------

        static void EnsureFolders()
        {
            string[] folders =
            {
                "Assets/Art", "Assets/Art/Placeholders", "Assets/Animations", "Assets/Audio", "Assets/Materials",
                "Assets/Prefabs", "Assets/Scenes", "Assets/ScriptableObjects", "Assets/ScriptableObjects/Skills",
                "Assets/ScriptableObjects/Enemies", "Assets/Settings"
            };
            foreach (var f in folders)
            {
                if (AssetDatabase.IsValidFolder(f)) continue;
                string parent = Path.GetDirectoryName(f).Replace('\\', '/');
                AssetDatabase.CreateFolder(parent, Path.GetFileName(f));
            }
        }

        static void ConfigurePlayerSettings()
        {
            PlayerSettings.companyName = "SeuEstudio";
            PlayerSettings.productName = "Cinzas de Aldrath";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.seuestudio.cinzasdealdrath");
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.AutoRotation;
            PlayerSettings.allowedAutorotateToPortrait = false;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = true;
            PlayerSettings.allowedAutorotateToLandscapeRight = true;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7 | AndroidArchitecture.ARM64;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.colorSpace = ColorSpace.Gamma;
        }

        // ---------- Sprites e materiais ----------

        static Sprite MakeSprite(string name, int size, bool circle, float pixelsPerUnit)
        {
            string path = "Assets/Art/Placeholders/" + name + ".png";
            if (!File.Exists(path))
            {
                var tex = new Texture2D(size, size, TextureFormat.RGBA32, false);
                var pixels = new Color32[size * size];
                float c = (size - 1) / 2f;
                float r = size / 2f;
                for (int y = 0; y < size; y++)
                {
                    for (int x = 0; x < size; x++)
                    {
                        byte a = 255;
                        if (circle)
                        {
                            float d = Vector2.Distance(new Vector2(x, y), new Vector2(c, c));
                            a = (byte)(Mathf.Clamp01(r - d) * 255f);
                        }
                        pixels[y * size + x] = new Color32(255, 255, 255, a);
                    }
                }
                tex.SetPixels32(pixels);
                File.WriteAllBytes(path, tex.EncodeToPNG());
                Object.DestroyImmediate(tex);
                AssetDatabase.ImportAsset(path);
            }

            var importer = (TextureImporter)AssetImporter.GetAtPath(path);
            importer.textureType = TextureImporterType.Sprite;
            importer.spriteImportMode = SpriteImportMode.Single;
            importer.spritePixelsPerUnit = pixelsPerUnit;
            importer.mipmapEnabled = false;
            importer.alphaIsTransparency = true;
            importer.filterMode = FilterMode.Bilinear;
            importer.textureCompression = TextureImporterCompression.Uncompressed;
            importer.SaveAndReimport();
            return AssetDatabase.LoadAssetAtPath<Sprite>(path);
        }

        static PhysicsMaterial2D MakeNoFrictionMaterial()
        {
            string path = "Assets/Materials/NoFriction.physicsMaterial2D";
            var existing = AssetDatabase.LoadAssetAtPath<PhysicsMaterial2D>(path);
            if (existing != null) return existing;
            var mat = new PhysicsMaterial2D("NoFriction") { friction = 0f, bounciness = 0f };
            AssetDatabase.CreateAsset(mat, path);
            return mat;
        }

        // ---------- Helpers de serialização ----------

        static SerializedProperty Prop(Object target, string name)
        {
            var so = new SerializedObject(target);
            var p = so.FindProperty(name);
            if (p == null) Debug.LogError("Propriedade '" + name + "' não encontrada em " + target.GetType().Name);
            return p;
        }

        static void SetRef(Object target, string name, Object value)
        {
            var p = Prop(target, name);
            if (p == null) return;
            p.objectReferenceValue = value;
            p.serializedObject.ApplyModifiedPropertiesWithoutUndo();
        }

        static void SetFloat(Object target, string name, float value)
        {
            var p = Prop(target, name);
            if (p == null) return;
            p.floatValue = value;
            p.serializedObject.ApplyModifiedPropertiesWithoutUndo();
        }

        static void SetBool(Object target, string name, bool value)
        {
            var p = Prop(target, name);
            if (p == null) return;
            p.boolValue = value;
            p.serializedObject.ApplyModifiedPropertiesWithoutUndo();
        }

        static void SetEnum(Object target, string name, int index)
        {
            var p = Prop(target, name);
            if (p == null) return;
            p.enumValueIndex = index;
            p.serializedObject.ApplyModifiedPropertiesWithoutUndo();
        }

        static void SetRect(Object target, string name, Rect value)
        {
            var p = Prop(target, name);
            if (p == null) return;
            p.rectValue = value;
            p.serializedObject.ApplyModifiedPropertiesWithoutUndo();
        }

        static void SetColor(Object target, string name, Color value)
        {
            var p = Prop(target, name);
            if (p == null) return;
            p.colorValue = value;
            p.serializedObject.ApplyModifiedPropertiesWithoutUndo();
        }

        // ---------- Objetos de jogo ----------

        static GameObject SpriteChild(string name, Transform parent, Sprite sprite, Color color, Vector3 localPos, Vector2 scale, int order)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = new Vector3(scale.x, scale.y, 1f);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = sprite;
            sr.color = color;
            sr.sortingOrder = order;
            return go;
        }

        static GameObject SavePrefab(GameObject go, string path)
        {
            var prefab = PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
            return prefab;
        }

        static GameObject CreatePopupPrefab()
        {
            var go = new GameObject("DamagePopup");
            var mesh = go.AddComponent<TextMesh>();
            mesh.font = _font;
            mesh.fontSize = 64;
            mesh.characterSize = 0.12f;
            mesh.anchor = TextAnchor.MiddleCenter;
            mesh.alignment = TextAlignment.Center;
            mesh.text = "0";
            var renderer = go.GetComponent<MeshRenderer>();
            if (_font != null) renderer.sharedMaterial = _font.material;
            renderer.sortingOrder = 100;
            go.AddComponent<DamagePopup>();
            return SavePrefab(go, "Assets/Prefabs/DamagePopup.prefab");
        }

        static GameObject CreateFireballPrefab()
        {
            var go = new GameObject("Fireball");
            go.AddComponent<Projectile>();
            SpriteChild("Glow", go.transform, _circle, new Color(1f, 0.45f, 0.1f, 0.6f), Vector3.zero, new Vector2(0.7f, 0.7f), 20);
            SpriteChild("Core", go.transform, _circle, new Color(1f, 0.9f, 0.4f, 1f), Vector3.zero, new Vector2(0.38f, 0.38f), 21);
            return SavePrefab(go, "Assets/Prefabs/Fireball.prefab");
        }

        static GameObject CreateImpactPrefab()
        {
            var go = new GameObject("FireImpact");
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = _circle;
            sr.color = new Color(1f, 0.55f, 0.15f, 0.85f);
            sr.sortingOrder = 22;
            go.AddComponent<ImpactFlash>();
            return SavePrefab(go, "Assets/Prefabs/FireImpact.prefab");
        }

        static ProjectileSkillDefinition CreateFireballSkill(GameObject projectilePrefab, GameObject impactPrefab)
        {
            const string path = "Assets/ScriptableObjects/Skills/Fireball.asset";
            var skill = AssetDatabase.LoadAssetAtPath<ProjectileSkillDefinition>(path);
            if (skill == null)
            {
                skill = ScriptableObject.CreateInstance<ProjectileSkillDefinition>();
                AssetDatabase.CreateAsset(skill, path);
            }
            skill.skillId = "fireball";
            skill.displayName = "Fogo";
            skill.description = "Dispara uma bola de fogo que explode ao atingir um inimigo.";
            skill.damageType = DamageType.Fire;
            skill.baseDamage = 28f;
            skill.range = 9f;
            skill.cooldown = 2.5f;
            skill.manaCost = 15f;
            skill.projectileSpeed = 13f;
            skill.knockback = 4f;
            skill.aimAtNearestEnemy = true;
            skill.projectilePrefab = projectilePrefab.GetComponent<Projectile>();
            skill.impactPrefab = impactPrefab;
            skill.levels = new[]
            {
                new SkillLevel { damageMultiplier = 1.0f, rangeMultiplier = 1.0f, areaRadius = 1.2f, cooldownMultiplier = 1.0f, upgradeCost = 1 },
                new SkillLevel { damageMultiplier = 1.35f, rangeMultiplier = 1.1f, areaRadius = 1.5f, cooldownMultiplier = 0.95f, upgradeCost = 2 },
                new SkillLevel { damageMultiplier = 1.7f, rangeMultiplier = 1.2f, areaRadius = 1.8f, cooldownMultiplier = 0.9f, upgradeCost = 3 }
            };
            EditorUtility.SetDirty(skill);
            return skill;
        }

        static EnemyDefinition CreateEnemyDefinition()
        {
            const string path = "Assets/ScriptableObjects/Enemies/AshGrub.asset";
            var def = AssetDatabase.LoadAssetAtPath<EnemyDefinition>(path);
            if (def == null)
            {
                def = ScriptableObject.CreateInstance<EnemyDefinition>();
                AssetDatabase.CreateAsset(def, path);
            }
            def.enemyId = "ash_grub";
            def.displayName = "Larva de Cinza";
            def.maxHealth = 45f;
            def.defense = 2f;
            def.moveSpeed = 2.6f;
            def.detectRange = 8f;
            def.attackRange = 1.2f;
            def.attackDamage = 9f;
            def.attackCooldown = 1.3f;
            def.attackWindup = 0.4f;
            def.xpReward = 18;
            def.goldReward = 6;
            def.tint = new Color(0.85f, 0.35f, 0.3f);
            EditorUtility.SetDirty(def);
            return def;
        }

        static GameObject CreateEnemyPrefab(EnemyDefinition def)
        {
            var go = new GameObject("AshGrub");

            var rb = go.AddComponent<Rigidbody2D>();
            rb.gravityScale = 3f;
            rb.freezeRotation = true;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

            var col = go.AddComponent<BoxCollider2D>();
            col.size = new Vector2(1f, 0.9f);
            col.sharedMaterial = _noFriction;

            go.AddComponent<ActorCollisionFilter>();
            var health = go.AddComponent<Health>();
            SetEnum(health, "team", (int)Team.Enemy);
            go.AddComponent<KnockbackReceiver>();
            go.AddComponent<MeleeAttack>();
            var controller = go.AddComponent<EnemyController>();
            SetRef(controller, "definition", def);

            // Corpo com pivô nos pés (para squash/stretch)
            var body = new GameObject("Body");
            body.transform.SetParent(go.transform, false);
            body.transform.localPosition = new Vector3(0f, -0.45f, 0f);
            var sprite = SpriteChild("Sprite", body.transform, _square, def.tint, new Vector3(0f, 0.45f, 0f), new Vector2(1f, 0.9f), 5);
            SpriteChild("Eye", body.transform, _square, Color.white, new Vector3(0.25f, 0.6f, 0f), new Vector2(0.2f, 0.2f), 6);

            var visual = go.AddComponent<ActorVisual>();
            SetRef(visual, "body", body.transform);
            SetRef(visual, "sprite", sprite.GetComponent<SpriteRenderer>());
            SetColor(visual, "baseColor", def.tint);

            // Barra de vida
            var bar = new GameObject("HealthBar");
            bar.transform.SetParent(go.transform, false);
            bar.transform.localPosition = new Vector3(0f, 0.85f, 0f);
            var barVisual = new GameObject("Visual");
            barVisual.transform.SetParent(bar.transform, false);
            SpriteChild("Back", barVisual.transform, _square, new Color(0f, 0f, 0f, 0.7f), Vector3.zero, new Vector2(1.04f, 0.16f), 30);
            var fill = SpriteChild("Fill", barVisual.transform, _square, new Color(0.85f, 0.2f, 0.25f), Vector3.zero, new Vector2(1f, 0.1f), 31);
            var hb = bar.AddComponent<WorldHealthBar>();
            SetRef(hb, "health", health);
            SetRef(hb, "fill", fill.transform);
            SetRef(hb, "visualRoot", barVisual);

            return SavePrefab(go, "Assets/Prefabs/AshGrub.prefab");
        }

        static GameObject CreatePlayerPrefab(SkillDefinition fireball)
        {
            var go = new GameObject("Player");

            var rb = go.AddComponent<Rigidbody2D>();
            rb.gravityScale = 3f;
            rb.freezeRotation = true;
            rb.interpolation = RigidbodyInterpolation2D.Interpolate;
            rb.collisionDetectionMode = CollisionDetectionMode2D.Continuous;

            var col = go.AddComponent<BoxCollider2D>();
            col.size = new Vector2(0.8f, 1.6f);
            col.sharedMaterial = _noFriction;

            go.AddComponent<ActorCollisionFilter>();

            var health = go.AddComponent<Health>();
            SetEnum(health, "team", (int)Team.Player);
            SetFloat(health, "maxHealth", 100f);
            SetFloat(health, "defense", 5f);
            SetFloat(health, "invulnerabilityTime", 0.6f);

            go.AddComponent<KnockbackReceiver>();
            go.AddComponent<Mana>();
            var melee = go.AddComponent<MeleeAttack>();
            var caster = go.AddComponent<SkillCaster>();
            go.AddComponent<PlayerProgress>();
            go.AddComponent<PlayerController>();

            // Corpo com pivô nos pés
            var body = new GameObject("Body");
            body.transform.SetParent(go.transform, false);
            body.transform.localPosition = new Vector3(0f, -0.8f, 0f);
            var playerColor = new Color(0.3f, 0.6f, 1f);
            var sprite = SpriteChild("Sprite", body.transform, _square, playerColor, new Vector3(0f, 0.8f, 0f), new Vector2(0.8f, 1.6f), 10);
            SpriteChild("Eye", body.transform, _square, Color.white, new Vector3(0.18f, 1.25f, 0f), new Vector2(0.22f, 0.22f), 11);

            var visual = go.AddComponent<ActorVisual>();
            SetRef(visual, "body", body.transform);
            SetRef(visual, "sprite", sprite.GetComponent<SpriteRenderer>());
            SetColor(visual, "baseColor", playerColor);

            // Efeito do golpe
            var slash = SpriteChild("Slash", go.transform, _square, new Color(1f, 1f, 1f, 0.6f), new Vector3(0.9f, 0f, 0f), new Vector2(1.3f, 0.9f), 12);
            slash.SetActive(false);
            SetRef(melee, "slashVisual", slash.transform);

            // Slot 1 = bola de fogo
            var so = new SerializedObject(caster);
            var slots = so.FindProperty("slots");
            slots.arraySize = 3;
            for (int i = 0; i < 3; i++)
                slots.GetArrayElementAtIndex(i).FindPropertyRelative("level").intValue = 1;
            slots.GetArrayElementAtIndex(0).FindPropertyRelative("skill").objectReferenceValue = fireball;
            so.ApplyModifiedPropertiesWithoutUndo();

            return SavePrefab(go, "Assets/Prefabs/Player.prefab");
        }

        // ---------- Cena ----------

        static GameObject Block(string name, Vector2 position, Vector2 size, Color color, bool oneWay)
        {
            var go = new GameObject(name);
            go.transform.position = position;
            go.transform.localScale = new Vector3(size.x, size.y, 1f);
            var sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = _square;
            sr.color = color;
            sr.sortingOrder = 0;
            var col = go.AddComponent<BoxCollider2D>();
            col.sharedMaterial = _noFriction;
            if (oneWay)
            {
                col.usedByEffector = true;
                var effector = go.AddComponent<PlatformEffector2D>();
                effector.useOneWay = true;
                effector.surfaceArc = 170f;
            }
            return go;
        }

        static void CreateScene(GameObject playerPrefab, GameObject enemyPrefab, GameObject popupPrefab)
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);

            // Câmera
            var camGo = new GameObject("Main Camera") { tag = "MainCamera" };
            var cam = camGo.AddComponent<Camera>();
            cam.orthographic = true;
            cam.orthographicSize = 5.5f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.09f, 0.08f, 0.11f);
            camGo.transform.position = new Vector3(0f, 0f, -10f);
            camGo.AddComponent<AudioListener>();
            var follow = camGo.AddComponent<CameraFollow>();

            // Cenário
            var ground = new Color(0.26f, 0.22f, 0.2f);
            var plat = new Color(0.4f, 0.32f, 0.26f);
            var world = new GameObject("Level");
            Block("Ground", new Vector2(10f, -4f), new Vector2(60f, 2f), ground, false).transform.SetParent(world.transform);
            Block("WallLeft", new Vector2(-20.5f, 2f), new Vector2(1f, 20f), ground, false).transform.SetParent(world.transform);
            Block("WallRight", new Vector2(40.5f, 2f), new Vector2(1f, 20f), ground, false).transform.SetParent(world.transform);
            Block("Platform1", new Vector2(6f, -0.8f), new Vector2(5f, 0.5f), plat, true).transform.SetParent(world.transform);
            Block("Platform2", new Vector2(14f, 1.6f), new Vector2(4f, 0.5f), plat, true).transform.SetParent(world.transform);
            Block("Platform3", new Vector2(24f, -0.8f), new Vector2(6f, 0.5f), plat, true).transform.SetParent(world.transform);

            // Jogador
            var player = (GameObject)PrefabUtility.InstantiatePrefab(playerPrefab);
            player.transform.position = new Vector3(-8f, -2.1f, 0f);
            SetRef(follow, "target", player.transform);
            SetBool(follow, "useBounds", true);
            SetRect(follow, "bounds", new Rect(-20f, -9f, 60f, 24f));

            // Pontos de surgimento
            var spawns = new GameObject("EnemySpawns");
            Vector2[] points = { new Vector2(4f, -2.5f), new Vector2(12f, -2.5f), new Vector2(20f, -2.5f), new Vector2(28f, -2.5f) };
            for (int i = 0; i < points.Length; i++)
            {
                var sp = new GameObject("Spawn" + (i + 1));
                sp.transform.SetParent(spawns.transform, false);
                sp.transform.position = points[i];
                var spawn = sp.AddComponent<EnemySpawnPoint>();
                SetRef(spawn, "prefab", enemyPrefab);
            }

            // EventSystem
            var es = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));

            // HUD e controles
            var hud = BuildHud(player);

            // Sistemas
            var systems = new GameObject("Systems");
            var feedback = systems.AddComponent<CombatFeedback>();
            SetRef(feedback, "popupPrefab", popupPrefab.GetComponent<DamagePopup>());
            var manager = systems.AddComponent<GameManager>();
            SetRef(manager, "player", player.GetComponent<PlayerController>());
            SetRef(manager, "hud", hud);

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
        }

        // ---------- HUD ----------

        static RectTransform Rt(Transform parent, string name, Vector2 anchorMin, Vector2 anchorMax, Vector2 pivot, Vector2 pos, Vector2 size)
        {
            var go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            var rt = (RectTransform)go.transform;
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.pivot = pivot;
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        static Image AddImage(RectTransform rt, Sprite sprite, Color color, bool raycast)
        {
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = sprite;
            img.color = color;
            img.raycastTarget = raycast;
            return img;
        }

        static Text AddText(RectTransform rt, string text, int size, TextAnchor anchor, Color color)
        {
            var t = rt.gameObject.AddComponent<Text>();
            t.font = _font;
            t.text = text;
            t.fontSize = size;
            t.alignment = anchor;
            t.color = color;
            t.raycastTarget = false;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            return t;
        }

        static Image Bar(RectTransform parent, string name, Vector2 pos, Vector2 size, Color color)
        {
            var back = Rt(parent, name, new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1), new Vector2(pos.x, -pos.y), size);
            AddImage(back, _square, new Color(0f, 0f, 0f, 0.55f), false);
            var fillRt = Rt(back, "Fill", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            fillRt.offsetMin = new Vector2(3f, 3f);
            fillRt.offsetMax = new Vector2(-3f, -3f);
            var fill = AddImage(fillRt, _square, color, false);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.fillOrigin = 0;
            fill.fillAmount = 1f;
            return fill;
        }

        static void RoundButton(RectTransform safe, string name, ButtonId id, Vector2 pos, float size, Color color, string label, int fontSize,
            out Text labelText, out Image overlay, out Text cooldownText, out GameObject root)
        {
            var rt = Rt(safe, name, new Vector2(1, 0), new Vector2(1, 0), new Vector2(0.5f, 0.5f), pos, new Vector2(size, size));
            AddImage(rt, _circle, color, true);
            var tb = rt.gameObject.AddComponent<TouchButton>();
            tb.id = id;

            var overlayRt = Rt(rt, "Cooldown", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            overlay = AddImage(overlayRt, _circle, new Color(0f, 0f, 0f, 0.65f), false);
            overlay.type = Image.Type.Filled;
            overlay.fillMethod = Image.FillMethod.Radial360;
            overlay.fillOrigin = 2;
            overlay.fillClockwise = false;
            overlay.fillAmount = 0f;

            var labelRt = Rt(rt, "Label", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            labelText = AddText(labelRt, label, fontSize, TextAnchor.MiddleCenter, Color.white);

            var cdRt = Rt(rt, "CooldownText", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            cooldownText = AddText(cdRt, "", fontSize + 8, TextAnchor.MiddleCenter, Color.white);
            root = rt.gameObject;
        }

        static HudController BuildHud(GameObject player)
        {
            var canvasGo = new GameObject("Canvas", typeof(RectTransform), typeof(Canvas), typeof(CanvasScaler), typeof(GraphicRaycaster));
            var canvas = canvasGo.GetComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 10;
            var scaler = canvasGo.GetComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            scaler.matchWidthOrHeight = 0.5f;

            var safe = Rt(canvasGo.transform, "SafeArea", Vector2.zero, Vector2.one, new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            safe.gameObject.AddComponent<SafeAreaFitter>();

            var hud = canvasGo.AddComponent<HudController>();
            hud.playerHealth = player.GetComponent<Health>();
            hud.playerMana = player.GetComponent<Mana>();
            hud.progress = player.GetComponent<PlayerProgress>();
            hud.caster = player.GetComponent<SkillCaster>();

            // Barras (canto superior esquerdo)
            hud.healthFill = Bar(safe, "HealthBar", new Vector2(40f, 40f), new Vector2(420f, 34f), new Color(0.85f, 0.2f, 0.25f));
            hud.manaFill = Bar(safe, "ManaBar", new Vector2(40f, 82f), new Vector2(420f, 24f), new Color(0.25f, 0.5f, 0.95f));
            hud.xpFill = Bar(safe, "XpBar", new Vector2(40f, 112f), new Vector2(420f, 14f), new Color(0.9f, 0.8f, 0.3f));
            hud.healthFill.fillAmount = 1f;

            var hpTextRt = Rt(safe, "HealthText", new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1), new Vector2(50f, -40f), new Vector2(400f, 34f));
            hud.healthText = AddText(hpTextRt, "100 / 100", 24, TextAnchor.MiddleLeft, Color.white);
            var lvRt = Rt(safe, "LevelText", new Vector2(0, 1), new Vector2(0, 1), new Vector2(0, 1), new Vector2(480f, -40f), new Vector2(200f, 40f));
            hud.levelText = AddText(lvRt, "Nv 1", 32, TextAnchor.MiddleLeft, Color.white);
            var goldRt = Rt(safe, "GoldText", new Vector2(1, 1), new Vector2(1, 1), new Vector2(1, 1), new Vector2(-40f, -40f), new Vector2(360f, 44f));
            hud.goldText = AddText(goldRt, "Ouro 0", 32, TextAnchor.MiddleRight, new Color(1f, 0.9f, 0.4f));

            var msgRt = Rt(safe, "Message", new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(0f, 100f), new Vector2(900f, 140f));
            hud.messageText = AddText(msgRt, "", 80, TextAnchor.MiddleCenter, Color.white);

            // Direcional (canto inferior esquerdo)
            var dpad = Rt(safe, "DPad", Vector2.zero, Vector2.zero, Vector2.zero, new Vector2(60f, 60f), new Vector2(480f, 230f));
            AddImage(dpad, _square, new Color(1f, 1f, 1f, 0.12f), true);
            dpad.gameObject.AddComponent<VirtualDPad>();
            var left = Rt(dpad, "Left", new Vector2(0, 0), new Vector2(0.5f, 1), new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            AddText(left, "<", 110, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.7f));
            var right = Rt(dpad, "Right", new Vector2(0.5f, 0), new Vector2(1, 1), new Vector2(0.5f, 0.5f), Vector2.zero, Vector2.zero);
            AddText(right, ">", 110, TextAnchor.MiddleCenter, new Color(1f, 1f, 1f, 0.7f));

            // Botões (canto inferior direito)
            RoundButton(safe, "AttackButton", ButtonId.Attack, new Vector2(-130f, 130f), 210f, new Color(0.95f, 0.35f, 0.3f, 0.6f), "Atacar", 34,
                out _, out _, out _, out _);
            RoundButton(safe, "JumpButton", ButtonId.Jump, new Vector2(-380f, 100f), 170f, new Color(0.4f, 0.7f, 1f, 0.6f), "Pular", 30,
                out _, out _, out _, out _);

            hud.skillButtons = new GameObject[3];
            hud.skillLabels = new Text[3];
            hud.skillCooldownOverlays = new Image[3];
            hud.skillCooldownTexts = new Text[3];
            Vector2[] skillPos = { new Vector2(-370f, 290f), new Vector2(-220f, 375f), new Vector2(-80f, 350f) };
            ButtonId[] skillIds = { ButtonId.Skill1, ButtonId.Skill2, ButtonId.Skill3 };
            for (int i = 0; i < 3; i++)
            {
                RoundButton(safe, "Skill" + (i + 1) + "Button", skillIds[i], skillPos[i], i == 2 ? 120f : 130f,
                    new Color(1f, 0.55f, 0.2f, 0.65f), "", 26,
                    out hud.skillLabels[i], out hud.skillCooldownOverlays[i], out hud.skillCooldownTexts[i], out hud.skillButtons[i]);
            }

            return hud;
        }
    }
}
